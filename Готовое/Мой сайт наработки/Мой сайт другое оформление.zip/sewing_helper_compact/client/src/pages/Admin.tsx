import { useMemo, useState } from "react";
import { ArrowLeft, LockKeyhole, Search, ShieldCheck } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";

export default function Admin() {
  const { user, loading } = useAuth();
  const { data: rows = [], isLoading, error } = trpc.submissions.list.useQuery(undefined, { enabled: Boolean(user?.role === "admin") });
  const utils = trpc.useUtils();
  const updateStatus = trpc.submissions.updateStatus.useMutation({ onSuccess: () => utils.submissions.list.invalidate() });
  const [query, setQuery] = useState("");
  const [kind, setKind] = useState<"all" | "consent" | "signup">("all");
  const [selected, setSelected] = useState<number | null>(null);

  const filtered = useMemo(() => rows.filter((row) => {
    const haystack = `${row.firstName} ${row.lastName ?? ""} ${row.email ?? ""} ${row.comment ?? ""}`.toLowerCase();
    return (kind === "all" || row.kind === kind) && haystack.includes(query.toLowerCase());
  }), [rows, query, kind]);
  const active = rows.find((row) => row.id === selected);
  const changeStatus = (id: number, status: "new" | "processed" | "archived") => updateStatus.mutate({ id, status });
  const statusLabel = (status: string) => status === "new" ? "Новая" : status === "processed" ? "Обработана" : "Архив";

  if (loading) return <div className="admin-shell"><div className="admin-loading">Проверяем доступ…</div></div>;
  if (!user) return <div className="admin-shell"><div className="admin-gate"><LockKeyhole size={28} /><span className="admin-kicker">Закрытая зона</span><h1>Вход администратора</h1><p>Авторизуйтесь, чтобы открыть журнал заявок.</p><button className="primary-button" onClick={() => startLogin()}>Войти в кабинет</button><a href="/">Вернуться на сайт <ArrowLeft size={14} /></a></div></div>;
  if (user.role !== "admin") return <div className="admin-shell"><div className="admin-gate"><ShieldCheck size={28} /><span className="admin-kicker">Доступ ограничен</span><h1>Недостаточно прав</h1><p>Журнал заявок доступен только пользователю с ролью администратора.</p><a href="/">Вернуться на сайт <ArrowLeft size={14} /></a></div></div>;

  return <div className="admin-shell"><header className="admin-header"><div><span className="admin-kicker">Право / доступ · операторский кабинет</span><h1>Журнал заявок</h1><p>Серверные записи согласий и обращений участников.</p></div><a href="/" className="admin-back"><ArrowLeft size={15} /> На сайт</a></header><main className="admin-main"><div className="admin-toolbar"><label className="admin-search"><Search size={16} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Поиск по имени, e-mail или комментарию" /></label><select value={kind} onChange={(e) => setKind(e.target.value as typeof kind)}><option value="all">Все типы</option><option value="consent">Согласия</option><option value="signup">Заявки на занятия</option></select><span className="admin-count">Показано: {filtered.length}</span></div>{error && <div className="admin-error">Не удалось загрузить журнал. Проверьте авторизацию администратора.</div>}{isLoading ? <div className="admin-empty">Загружаем заявки…</div> : filtered.length === 0 ? <div className="admin-empty">Заявок пока нет или ничего не найдено.</div> : <div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Дата</th><th>Тип</th><th>Участник</th><th>E-mail</th><th>Статус</th><th /></tr></thead><tbody>{filtered.map((row) => <tr key={row.id} onClick={() => setSelected(row.id)}><td>{new Date(row.createdAt).toLocaleString("ru-RU")}</td><td><span className={`admin-badge ${row.kind === "consent" ? "is-consent" : "is-signup"}`}>{row.kind === "consent" ? "Согласие" : "Заявка"}</span></td><td><b>{row.firstName} {row.lastName ?? ""}</b><small>{row.meetingFormat ?? ""}</small></td><td>{row.email || "—"}</td><td><select className="admin-status-select" value={row.status} disabled={updateStatus.isPending} onClick={(e) => e.stopPropagation()} onChange={(e) => changeStatus(row.id, e.target.value as "new" | "processed" | "archived")}><option value="new">Новая</option><option value="processed">Обработана</option><option value="archived">Архив</option></select></td><td><button className="admin-details" onClick={(e) => { e.stopPropagation(); setSelected(row.id); }}>Открыть</button></td></tr>)}</tbody></table></div>}</main>{active && <div className="admin-drawer-backdrop" onClick={() => setSelected(null)}><aside className="admin-drawer" onClick={(e) => e.stopPropagation()}><button className="drawer-close" onClick={() => setSelected(null)}>Закрыть</button><span className="admin-kicker">Запись #{active.id}</span><h2>{active.firstName} {active.lastName ?? ""}</h2><dl><dt>Тип</dt><dd>{active.kind === "consent" ? "Регистрация согласия" : "Заявка на занятие"}</dd><dt>E-mail</dt><dd>{active.email || "Не указан"}</dd><dt>Формат</dt><dd>{active.meetingFormat || "Не указан"}</dd><dt>Согласие</dt><dd>{active.consentGranted ? "Подтверждено" : "Не требуется"}</dd><dt>Дата</dt><dd>{new Date(active.createdAt).toLocaleString("ru-RU")}</dd><dt>Статус</dt><dd><select className="admin-status-select drawer-status" value={active.status} disabled={updateStatus.isPending} onChange={(e) => changeStatus(active.id, e.target.value as "new" | "processed" | "archived")}><option value="new">Новая</option><option value="processed">Обработана</option><option value="archived">Архив</option></select>{updateStatus.isPending && <small>Сохраняем…</small>}</dd></dl>{active.comment && <div className="drawer-comment"><span>Комментарий</span><p>{active.comment}</p></div>}</aside></div>}</div>;
}
