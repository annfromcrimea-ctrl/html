import { useEffect, useMemo, useState } from "react";
import type { FormEvent } from "react";
import { trpc } from "@/lib/trpc";
import {
  ArrowDownRight,
  ArrowUpRight,
  Check,
  ChevronRight,
  ClipboardCheck,
  ExternalLink,
  FileText,
  Info,
  LockKeyhole,
  Mail,
  Menu,
  NotebookTabs,
  ShieldCheck,
  Sparkles,
  UserRound,
  X,
} from "lucide-react";

/**
 * Design reminder — Editorial utility / compact field guide.
 * Keep primary actions and legal steps visually dominant, compress supporting copy,
 * use warm paper + deep ink + mint accent, and preserve clear keyboard states.
 */

const HERO_IMAGE = "/manus-storage/compact-hero-editorial_44ea8e90.png";
const THUMB_IMAGE = "/manus-storage/compact-document-thumb_fc01455d.png";
const MARK_IMAGE = "/manus-storage/compact-mark_59fe1676.png";

const docs = [
  {
    id: "policy",
    number: "01",
    name: "Политика обработки персональных данных",
    meta: "обязательный документ · версия 1.2",
    href: "#policy",
  },
  {
    id: "offer",
    number: "02",
    name: "Публичная оферта",
    meta: "условия участия и доступа",
    href: "#offer",
  },
  {
    id: "privacy",
    number: "03",
    name: "Согласие на обработку данных",
    meta: "форма ПД-1 · требуется отметка",
    href: "#consent",
  },
  {
    id: "rules",
    number: "04",
    name: "Правила закрытого сообщества",
    meta: "общение, материалы, поддержка",
    href: "#rules",
  },
];

const initialForm = { firstName: "", lastName: "", email: "" };
const initialSignup = { firstName: "", email: "", format: "онлайн", comment: "" };

function AppMark({ small = false }: { small?: boolean }) {
  return (
    <div className={small ? "app-mark app-mark--small" : "app-mark"}>
      <img src={MARK_IMAGE} alt="" />
      <span className="mark-copy">
        <b>ПРАВО / ДОСТУП</b>
        <small>операторский кабинет</small>
      </span>
    </div>
  );
}

function StepRail({ activeStep, onStep }: { activeStep: number; onStep: (step: number) => void }) {
  const steps = ["Ознакомление", "Документы", "Данные", "Доступ"];
  return (
    <nav className="step-rail" aria-label="Этапы получения доступа">
      <div className="step-rail__inner">
        {steps.map((step, index) => {
          const n = index + 1;
          return (
            <button
              key={step}
              type="button"
              className={`rail-step ${activeStep === n ? "is-active" : ""} ${activeStep > n ? "is-done" : ""}`}
              onClick={() => onStep(n)}
            >
              <span className="rail-number">{activeStep > n ? <Check size={13} strokeWidth={3} /> : `0${n}`}</span>
              <span>{step}</span>
            </button>
          );
        })}
        <span className="rail-progress" style={{ width: `${Math.max(0, ((activeStep - 1) / 3) * 100)}%` }} />
      </div>
    </nav>
  );
}

function DocumentRow({ doc, checked, onCheck }: { doc: (typeof docs)[number]; checked: boolean; onCheck: () => void }) {
  return (
    <div className={`document-row ${checked ? "is-read" : ""}`}>
      <span className="document-index">{checked ? <Check size={15} /> : doc.number}</span>
      <div className="document-copy">
        <strong>{doc.name}</strong>
        <small>{doc.meta}</small>
      </div>
      <a className="text-action" href={doc.href}>
        Открыть <ExternalLink size={13} />
      </a>
      <label className="read-check">
        <input type="checkbox" checked={checked} onChange={onCheck} />
        <span className="check-box" aria-hidden="true">{checked ? <Check size={13} /> : null}</span>
        <span>Ознакомлен(а)</span>
      </label>
    </div>
  );
}

export default function Home() {
  const [flow, setFlow] = useState<"consent" | "signup">("consent");
  const [activeStep, setActiveStep] = useState(1);
  const [readDocs, setReadDocs] = useState<Record<string, boolean>>({});
  const [consent, setConsent] = useState(initialForm);
  const [signup, setSignup] = useState(initialSignup);
  const [newsletter, setNewsletter] = useState(false);
  const [consentAccepted, setConsentAccepted] = useState(false);
  const createSubmission = trpc.submissions.create.useMutation();
  const [consentSubmitted, setConsentSubmitted] = useState(false);
  const [signupSubmitted, setSignupSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState<"consent" | "signup" | null>(null);
  const [showTechnical, setShowTechnical] = useState(false);
  const [cookieVisible, setCookieVisible] = useState(true);
  const [notice, setNotice] = useState("");

  useEffect(() => {
    const saved = localStorage.getItem("compact-access-state");
    if (!saved) return;
    try {
      const parsed = JSON.parse(saved);
      setReadDocs(parsed.readDocs || {});
      setConsentSubmitted(Boolean(parsed.consentSubmitted));
      setSignupSubmitted(Boolean(parsed.signupSubmitted));
      setCookieVisible(parsed.cookieVisible !== false);
    } catch {
      // Ignore malformed local state and start fresh.
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(
      "compact-access-state",
      JSON.stringify({ readDocs, consentSubmitted, signupSubmitted, cookieVisible }),
    );
  }, [readDocs, consentSubmitted, signupSubmitted, cookieVisible]);

  const readCount = useMemo(() => docs.filter((doc) => readDocs[doc.id]).length, [readDocs]);
  const allDocsRead = readCount === docs.length;
  const clearFieldError = (field: string) => {
    setErrors((current) => {
      if (!current[field]) return current;
      const next = { ...current };
      delete next[field];
      return next;
    });
  };

  const isValidEmail = (value: string) => /^\S+@\S+\.\S+$/.test(value);

  const goTo = (step: number, id = `step-${step}`) => {
    setActiveStep(step);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const handleConsent = (event: FormEvent) => {
    event.preventDefault();
    const nextErrors: Record<string, string> = {};
    if (!consent.firstName.trim()) nextErrors.consentFirstName = "Укажите имя.";
    if (!consent.lastName.trim()) nextErrors.consentLastName = "Укажите фамилию.";
    if (consent.email && !isValidEmail(consent.email)) nextErrors.consentEmail = "Проверьте формат e-mail.";
    if (!consentAccepted) nextErrors.consentAccepted = "Подтвердите согласие, чтобы продолжить.";
    if (Object.keys(nextErrors).length) {
      setErrors(nextErrors);
      setNotice("Проверьте отмеченные поля перед регистрацией согласия.");
      return;
    }
    setErrors({});
    setSubmitting("consent");
    createSubmission.mutate({ kind: "consent", firstName: consent.firstName, lastName: consent.lastName, email: consent.email, consentGranted: true, documentVersion: "1.2" }, {
      onSuccess: () => { setSubmitting(null); setConsentSubmitted(true); setNotice("Согласие зарегистрировано. Шаг доступа открыт."); goTo(4, "step-4"); },
      onError: () => { setSubmitting(null); setNotice("Не удалось сохранить согласие. Повторите попытку."); },
    });
  };

  const handleSignup = (event: FormEvent) => {
    event.preventDefault();
    const nextErrors: Record<string, string> = {};
    if (!signup.firstName.trim()) nextErrors.signupFirstName = "Укажите имя для заявки.";
    if (!signup.email.trim()) nextErrors.signupEmail = "Укажите e-mail для связи.";
    else if (!isValidEmail(signup.email)) nextErrors.signupEmail = "Проверьте формат e-mail.";
    if (Object.keys(nextErrors).length) {
      setErrors(nextErrors);
      setNotice("Проверьте отмеченные поля перед отправкой заявки.");
      return;
    }
    setErrors({});
    setSubmitting("signup");
    createSubmission.mutate({ kind: "signup", firstName: signup.firstName, email: signup.email, meetingFormat: signup.format, comment: signup.comment, consentGranted: false }, {
      onSuccess: () => { setSubmitting(null); setSignupSubmitted(true); setNotice("Заявка отправлена. Мы свяжемся с вами для подтверждения формата."); },
      onError: () => { setSubmitting(null); setNotice("Не удалось отправить заявку. Повторите попытку."); },
    });
  };

  const setDocument = (id: string) => {
    setReadDocs((current) => ({ ...current, [id]: !current[id] }));
    setNotice("");
  };

  return (
    <div className="site-shell">
      <div className="topline">
        <div className="page-width topline__inner">
          <span className="topline__label"><ShieldCheck size={13} /> Оператор персональных данных · 152-ФЗ</span>
          <span className="topline__state"><i /> реестр открыт · 27 августа 2026</span>
        </div>
      </div>

      <header className="site-header page-width">
        <AppMark />
        <div className="header-actions">
          <button className={`header-tab ${flow === "consent" ? "is-selected" : ""}`} onClick={() => setFlow("consent")}>
            Согласие и доступ
          </button>
          <button className={`header-tab ${flow === "signup" ? "is-selected" : ""}`} onClick={() => setFlow("signup")}>
            Запись на занятия
          </button>
          <button className="icon-button" aria-label="Открыть меню"><Menu size={18} /></button>
        </div>
      </header>

      <main>
        <section className="hero page-width">
          <div className="hero-copy">
            <div className="eyebrow"><span /> Федеральный закон № 152-ФЗ о персональных данных</div>
            <h1>Проверьте документы —<br /><em>затем откройте доступ.</em></h1>
            <p className="hero-lead">
              Короткий маршрут для участников закрытых сообществ и занятий. Заполните обязательные поля, ознакомьтесь с документами и получите доступ после регистрации согласия.
            </p>
            <div className="hero-meta">
              <span><ClipboardCheck size={14} /> 4 шага</span>
              <span><Sparkles size={14} /> 2 минуты</span>
              <span><LockKeyhole size={14} /> данные остаются в браузере</span>
            </div>
            <div className="hero-actions">
              <button className="primary-button" onClick={() => goTo(1)}>
                Начать оформление <ArrowDownRight size={16} />
              </button>
              <button className="quiet-button" onClick={() => setShowTechnical((value) => !value)}>
                Как это работает <Info size={15} />
              </button>
            </div>
            {showTechnical && (
              <div className="inline-note"><Info size={15} /> Сначала вы отмечаете документы, затем отправляете форму. Доступ открывается только после успешной регистрации обязательных данных.</div>
            )}
          </div>
          <div className="hero-visual">
            <div className="hero-image-frame">
              <img src={HERO_IMAGE} alt="Документы и подтверждение согласия" />
              <div className="hero-stamp"><Check size={14} /> ПД-1<br /><small>готово к проверке</small></div>
            </div>
            <span className="visual-caption">01 / спокойный порядок действий</span>
          </div>
        </section>

        <StepRail activeStep={activeStep} onStep={goTo} />

        {notice && <div className="page-width global-notice" role="status"><Info size={16} /> {notice}<button aria-label="Закрыть сообщение" onClick={() => setNotice("")}><X size={15} /></button></div>}

        <section id="step-1" className="content-section page-width">
          <div className="section-kicker">Шаг 01 / ознакомление</div>
          <div className="section-heading">
            <div><span className="section-number">01</span><h2>Что вас ждёт<br />в закрытых сообществах</h2></div>
            <p>Сначала — коротко о формате. Никаких лишних полей и скрытых условий.</p>
          </div>
          <div className="editorial-grid">
            <div className="reading-column">
              <p className="lead-paragraph">Здесь собраны материалы и занятия, которые доступны участникам после подтверждения согласия. Вы сможете вернуться к документам в любой момент.</p>
              <div className="quote-note">«Порядок важнее спешки: сначала понятные условия, потом удобный доступ.»</div>
              <div className="mini-facts"><div><b>01</b><span>собранные материалы</span></div><div><b>02</b><span>занятия и разборы</span></div><div><b>03</b><span>поддержка участников</span></div></div>
              <button className="section-link" onClick={() => goTo(2, "step-2")}>Перейти к документам <ChevronRight size={16} /></button>
            </div>
            <aside className="info-panel">
              <div className="panel-label">внутри сообщества</div>
              <div className="thumb-wrap"><img src={THUMB_IMAGE} alt="Миниатюра документов" /></div>
              {["уроки и записи", "практические материалы", "обратная связь", "анонсы встреч"].map((item) => <div className="panel-line" key={item}><Check size={14} /> <span>{item}</span></div>)}
            </aside>
          </div>
        </section>

        <section id="step-2" className="content-section content-section--tint page-width">
          <div className="section-kicker">Шаг 02 / документы</div>
          <div className="section-heading section-heading--inline"><div><span className="section-number">02</span><h2>Ознакомьтесь с условиями</h2></div><span className="progress-count">{readCount} / {docs.length} отмечено</span></div>
          <p className="section-intro">Откройте каждый документ и отметьте ознакомление. Это помогает пройти форму без повторных вопросов.</p>
          <div className="document-list">{docs.map((doc) => <DocumentRow key={doc.id} doc={doc} checked={Boolean(readDocs[doc.id])} onCheck={() => setDocument(doc.id)} />)}</div>
          <div className="section-footer"><span><NotebookTabs size={16} /> Документы открываются в текущем окне</span><button className="primary-button primary-button--small" onClick={() => goTo(3, "step-3")} disabled={!allDocsRead}>Продолжить <ChevronRight size={15} /></button></div>
        </section>

        <section id="step-3" className="content-section page-width">
          <div className="section-kicker">Шаг 03 / данные и согласие</div>
          <div className="section-heading section-heading--inline"><div><span className="section-number">03</span><h2>{flow === "consent" ? "Зарегистрируйте согласие" : "Оставьте заявку на занятие"}</h2></div><span className="required-note">* обязательные поля</span></div>
          {flow === "consent" ? (
            consentSubmitted ? (
              <div className="form-success" role="status" aria-live="polite">
                <div className="form-success__icon"><Check size={27} strokeWidth={3} /></div>
                <div><span className="success-eyebrow">Шаг 03 завершён</span><h3>Согласие зарегистрировано</h3><p>Спасибо, {consent.firstName || "участник"}. Доступ к материалам открыт, а состояние сохранено в вашем браузере.</p></div>
                <button className="primary-button primary-button--small" onClick={() => goTo(4, "step-4")}>Открыть доступ <ChevronRight size={15} /></button>
              </div>
            ) : <form className="form-layout" onSubmit={handleConsent} noValidate>
              <div className="form-main">
                <div className="form-grid"><label className={errors.consentFirstName ? "field-label is-error" : "field-label"}>Имя *<input aria-invalid={Boolean(errors.consentFirstName)} aria-describedby={errors.consentFirstName ? "consent-first-name-error" : undefined} className={errors.consentFirstName ? "is-error" : ""} value={consent.firstName} onChange={(e) => { setConsent({ ...consent, firstName: e.target.value }); clearFieldError("consentFirstName"); }} placeholder="Ваше имя" />{errors.consentFirstName && <small id="consent-first-name-error" className="field-error" role="alert">{errors.consentFirstName}</small>}</label><label className={errors.consentLastName ? "field-label is-error" : "field-label"}>Фамилия *<input aria-invalid={Boolean(errors.consentLastName)} aria-describedby={errors.consentLastName ? "consent-last-name-error" : undefined} className={errors.consentLastName ? "is-error" : ""} value={consent.lastName} onChange={(e) => { setConsent({ ...consent, lastName: e.target.value }); clearFieldError("consentLastName"); }} placeholder="Ваша фамилия" />{errors.consentLastName && <small id="consent-last-name-error" className="field-error" role="alert">{errors.consentLastName}</small>}</label><label className={`form-grid__wide field-label ${errors.consentEmail ? "is-error" : ""}`}>E-mail <span className="muted">необязательно</span><input aria-invalid={Boolean(errors.consentEmail)} aria-describedby={errors.consentEmail ? "consent-email-error" : undefined} className={errors.consentEmail ? "is-error" : ""} type="email" value={consent.email} onChange={(e) => { setConsent({ ...consent, email: e.target.value }); clearFieldError("consentEmail"); }} placeholder="name@example.com" />{errors.consentEmail && <small id="consent-email-error" className="field-error" role="alert">{errors.consentEmail}</small>}</label></div>
                <div className="consent-text">Я, действуя свободно, своей волей и в своём интересе, даю согласие <b>оператору персональных данных</b> на обработку моих данных для предоставления доступа к материалам, обработки заявок и связи для подтверждения записи. Подробные условия приведены в политике обработки персональных данных.</div>
                <label className={`required-check ${errors.consentAccepted ? "is-error" : ""}`}><input type="checkbox" checked={consentAccepted} aria-invalid={Boolean(errors.consentAccepted)} onChange={(e) => { setConsentAccepted(e.target.checked); clearFieldError("consentAccepted"); }} /><span className="check-box">{consentAccepted ? <Check size={13} /> : null}</span><span>Я ознакомлен(а) с условиями обработки данных и даю обязательное согласие <b>*</b>{errors.consentAccepted && <small className="field-error" role="alert">{errors.consentAccepted}</small>}</span></label>
                <label className="optional-check"><input type="checkbox" checked={newsletter} onChange={(e) => setNewsletter(e.target.checked)} /><span className="check-box">{newsletter ? <Check size={13} /> : null}</span><span>Хочу получать письма с анонсами и материалами <small>это согласие отдельное и необязательное</small></span></label>
                <div className="form-actions"><button className={`primary-button ${submitting === "consent" ? "is-sending" : ""}`} type="submit" disabled={submitting === "consent"}>{submitting === "consent" ? <><span className="button-spinner" />Проверяем…</> : <>Зарегистрировать согласие <ArrowUpRight size={16} /></>}</button><span className="form-hint"><LockKeyhole size={14} /> без передачи третьим лицам</span></div>
              </div>
              <aside className="side-note"><div className="side-note__icon"><UserRound size={17} /></div><b>Зачем нужны эти данные?</b><p>Чтобы подтвердить, кто получает доступ, и связаться с вами по заявке. E-mail можно не указывать.</p><a href="#policy">Подробнее о политике <ExternalLink size={13} /></a></aside>
            </form>
          ) : (
            signupSubmitted ? (
              <div className="form-success" role="status" aria-live="polite">
                <div className="form-success__icon"><Check size={27} strokeWidth={3} /></div>
                <div><span className="success-eyebrow">Заявка принята</span><h3>Спасибо, {signup.firstName || "участник"}</h3><p>Заявка сохранена в этом браузере. Мы используем указанные данные только для связи по выбранному формату занятия.</p></div>
                <button className="quiet-button" onClick={() => { setSignupSubmitted(false); setSignup(initialSignup); }}>Новая заявка <ChevronRight size={15} /></button>
              </div>
            ) : <form className="form-layout" onSubmit={handleSignup} noValidate>
              <div className="form-main"><div className="form-grid"><label className={errors.signupFirstName ? "field-label is-error" : "field-label"}>Имя *<input aria-invalid={Boolean(errors.signupFirstName)} aria-describedby={errors.signupFirstName ? "signup-first-name-error" : undefined} className={errors.signupFirstName ? "is-error" : ""} value={signup.firstName} onChange={(e) => { setSignup({ ...signup, firstName: e.target.value }); clearFieldError("signupFirstName"); }} placeholder="Ваше имя" />{errors.signupFirstName && <small id="signup-first-name-error" className="field-error" role="alert">{errors.signupFirstName}</small>}</label><label className={errors.signupEmail ? "field-label is-error" : "field-label"}>E-mail *<input aria-invalid={Boolean(errors.signupEmail)} aria-describedby={errors.signupEmail ? "signup-email-error" : undefined} className={errors.signupEmail ? "is-error" : ""} type="email" value={signup.email} onChange={(e) => { setSignup({ ...signup, email: e.target.value }); clearFieldError("signupEmail"); }} placeholder="name@example.com" />{errors.signupEmail && <small id="signup-email-error" className="field-error" role="alert">{errors.signupEmail}</small>}</label><label className="field-label">Формат встречи<select value={signup.format} onChange={(e) => setSignup({ ...signup, format: e.target.value })}><option>онлайн</option><option>очно</option><option>не определился(ась)</option></select></label><label className="field-label">Комментарий <span className="muted">необязательно</span><textarea value={signup.comment} onChange={(e) => setSignup({ ...signup, comment: e.target.value })} placeholder="Что хотите обсудить?" /></label></div><div className="form-actions"><button className={`primary-button ${submitting === "signup" ? "is-sending" : ""}`} type="submit" disabled={submitting === "signup"}>{submitting === "signup" ? <><span className="button-spinner" />Отправляем…</> : <>Отправить заявку <ArrowUpRight size={16} /></>}</button><span className="form-hint"><Mail size={14} /> ответим в рабочее время</span></div></div><aside className="side-note"><div className="side-note__icon"><Sparkles size={17} /></div><b>Формат под задачу</b><p>Оставьте вопрос в комментарии — мы предложим подходящий формат занятия и сообщим доступные даты.</p></aside></form>
          )}
        </section>

        <section id="step-4" className="content-section content-section--dark page-width">
          <div className="section-kicker section-kicker--light">Шаг 04 / доступ</div>
          <div className="access-layout"><div><span className="section-number section-number--light">04</span><h2>Доступ к материалам</h2><p>{consentSubmitted ? "Согласие зарегистрировано. Ссылки на материалы доступны ниже." : "Ссылки появятся после регистрации согласия."}</p></div><div className={`access-lock ${consentSubmitted ? "is-open" : ""}`}>{consentSubmitted ? <><Check size={22} /><b>доступ открыт</b></> : <><LockKeyhole size={22} /><b>доступ закрыт</b></>}</div></div>
          <div className={`access-content ${consentSubmitted ? "is-unlocked" : ""}`}>{consentSubmitted ? <div className="access-links"><a href="#materials"><FileText size={17} /><span><b>Материалы сообщества</b><small>перейти к закрытым материалам</small></span><ChevronRight size={16} /></a><a href="#calendar"><NotebookTabs size={17} /><span><b>Расписание занятий</b><small>ближайшие даты и записи</small></span><ChevronRight size={16} /></a></div> : <div className="locked-message"><LockKeyhole size={18} /> Содержимое станет доступно после регистрации согласия.</div>}</div>
        </section>

        <section className="operator-strip page-width"><div><span className="section-kicker">Техническая памятка оператору</span><h3>Перед публикацией проверьте реквизиты, ссылки на документы и контакт для отзыва согласия.</h3></div><button className="quiet-button" onClick={() => setShowTechnical((value) => !value)}>Открыть памятку <ChevronRight size={15} /></button></section>
      </main>

      <footer className="site-footer"><div className="page-width footer-grid"><AppMark small /><div><b>Документы</b><a href="#policy">Политика обработки ПД</a><a href="#offer">Публичная оферта</a></div><div><b>Обратная связь</b><a href="mailto:operator@example.com">operator@example.com</a><a href="#appeal">Отзыв согласия</a></div><div className="footer-meta">Работает локально в вашем браузере<br />© 2026 · версия интерфейса 2.0</div></div></footer>

      {cookieVisible && <div className="cookie-banner"><div><b>Небольшое техническое уведомление</b><p>Сайт использует локальное хранилище браузера, чтобы запомнить отмеченные документы и состояние формы. <a href="#cookie">Политика cookie</a></p></div><button className="primary-button primary-button--small" onClick={() => setCookieVisible(false)}>Понятно</button></div>}

      {signupSubmitted && <div className="toast"><Check size={17} /> Заявка сохранена в этом браузере.</div>}
    </div>
  );
}
