# Design brief — compact alternate site

## Ground-truth reference
The attached `/home/ubuntu/upload/index_улучшенный.html` is the source of truth for the structure, content hierarchy, workflow, and interaction patterns. The alternate version must preserve the same two primary flows, consent/access content, lesson signup content, document links, gated access state, cookie notice, and operator notes while changing the visual treatment.

## Chosen direction: Editorial utility / compact field guide

### Design Movement
Swiss editorial system blended with a compact field-guide dashboard: crisp typographic hierarchy, restrained geometry, precise rules, and a warm paper-like neutral surface.

### Core Principles
1. Primary actions and legal steps remain prominent; supporting copy is smaller and quieter.
2. Sections are compressed into clearly labeled bands, with dense but breathable information blocks.
3. The interface uses a deep ink header, warm ivory canvas, and one vivid mint accent instead of decorative gradients.
4. Every interaction stays keyboard-accessible and stateful, with compact controls that still preserve touch targets.

### Color Philosophy
The dark ink header conveys seriousness and trust for consent-related content. A warm ivory canvas reduces visual glare and evokes a working document. Mint is reserved for progress, active states, and links so the eye can scan the workflow instantly. Amber marks required attention without competing with the primary action.

### Layout Paradigm
A slim utility header and a compact horizontal step rail frame a two-column editorial body. Major sections are full-width bands; content-heavy areas use a narrow reading column paired with a compact aside. Supporting text is visually subordinate instead of occupying equal space with the main action.

### Signature Elements
- A numbered progress rail with compact labels and a thin active rule.
- Small uppercase mono labels for metadata, legal references, and section markers.
- Document rows that read like index cards, with reduced padding and clear action affordances.

### Interaction Philosophy
Interactions should feel immediate and procedural: choose a flow, scan the current step, complete only the required field, then continue. Checkboxes and buttons expose state clearly. Long explanations remain available but visually secondary.

### Animation
Use only short opacity/translate transitions for section changes, button feedback, and document completion. Avoid decorative looping animation except a subtle active status indicator. Respect reduced-motion preferences.

### Typography System
Use a strong humanist sans for headings, a compact system sans for body text, and a monospace utility face for metadata and legal labels. Heading scale is reduced relative to the reference; supporting copy is 12–15px, metadata 10–11px, and primary actions 12–13px.

### Brand Essence
A trustworthy compact access-and-consent workspace for course operators and participants, designed to make legally important steps easy to scan and complete.

Personality: precise, calm, practical.

### Brand Voice
Headlines are direct and reassuring. CTAs are action-oriented and specific; microcopy explains consequences without filler.

Example lines:
- “Проверьте документы — затем откройте доступ.”
- “Согласие зарегистрировано; следующий шаг доступен.”

### Wordmark & Logo
Use a simple scissors-and-leaf mark as a small geometric icon beside the wordmark; never rely on a default text-only logo treatment.

### Signature Brand Color
`#2F9E68` mint green — reserved for verified state, progress, and actionable links.

## Implementation constraints
The alternate site must remain a single self-contained HTML document with inline CSS and JavaScript, preserve the original Russian language, keep all existing form and local-storage behaviors, and reduce the visual weight of nonessential decorative art and long explanatory copy. No external assets are required; the compact look is achieved with CSS and inline vector/data marks already used by the reference.
