CREATE TABLE `submissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`kind` enum('consent','signup') NOT NULL,
	`firstName` varchar(120) NOT NULL,
	`lastName` varchar(120),
	`email` varchar(320),
	`meetingFormat` varchar(64),
	`comment` text,
	`consentGranted` int NOT NULL DEFAULT 0,
	`documentVersion` varchar(32),
	`status` enum('new','processed','archived') NOT NULL DEFAULT 'new',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `submissions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
--> statement-breakpoint
CREATE INDEX `submissions_createdAt_idx` ON `submissions` (`createdAt`);--> statement-breakpoint
CREATE INDEX `submissions_kind_idx` ON `submissions` (`kind`);