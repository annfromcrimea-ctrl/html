import { describe, expect, it } from "vitest";
import { getStorageProvider, validateUpload } from "./storage";

describe("storage upload validation", () => {
  it("accepts supported document and media types", () => {
    expect(() => validateUpload("hello", "text/plain")).not.toThrow();
    expect(() => validateUpload(new Uint8Array([1, 2, 3]), "application/pdf")).not.toThrow();
    expect(() => validateUpload(new Uint8Array([1, 2, 3]), "image/png")).not.toThrow();
  });

  it("rejects unsupported MIME types and oversized data", () => {
    expect(() => validateUpload("<script>alert(1)</script>", "text/html")).not.toThrow();
    expect(() => validateUpload("secret", "application/x-executable")).toThrow("MIME type is not allowed");
    expect(() => validateUpload("123456", "text/plain", 5)).toThrow("Upload exceeds maximum size");
  });

  it("uses the safe fallback provider until Yandex credentials are configured", () => {
    expect(getStorageProvider()).toBe("manus");
  });
});
