import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import { createSubmission, listSubmissions, updateSubmissionStatus } from "./db";

const submissionInput = z.object({
  kind: z.enum(["consent", "signup"]),
  firstName: z.string().trim().min(1).max(120),
  lastName: z.string().trim().max(120).optional(),
  email: z.string().trim().email().max(320).optional().or(z.literal("")),
  meetingFormat: z.string().max(64).optional(),
  comment: z.string().max(5000).optional(),
  consentGranted: z.boolean().default(false),
  documentVersion: z.string().max(32).optional(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(({ ctx }) => ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  submissions: router({
    create: publicProcedure.input(submissionInput).mutation(async ({ input }) => {
      if (input.kind === "consent" && !input.consentGranted) throw new Error("Consent is required");
      return createSubmission({ ...input, email: input.email || null, consentGranted: input.consentGranted ? 1 : 0 });
    }),
    list: adminProcedure.query(() => listSubmissions()),
    updateStatus: adminProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(["new", "processed", "archived"]) })).mutation(({ input }) => updateSubmissionStatus(input.id, input.status)),
  }),
});

export type AppRouter = typeof appRouter;
