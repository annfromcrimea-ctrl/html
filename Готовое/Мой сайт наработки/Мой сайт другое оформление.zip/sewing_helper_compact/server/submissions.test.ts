import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const baseContext = (role: "user" | "admin" | null): TrpcContext => ({
  user: role ? { id: 1, openId: `${role}-test`, name: "Test", email: "test@example.com", loginMethod: "test", role, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() } : null,
  req: {} as TrpcContext["req"],
  res: {} as TrpcContext["res"],
});

describe("submissions", () => {
  it("rejects a consent submission without explicit consent", async () => {
    const caller = appRouter.createCaller(baseContext(null));
    await expect(caller.submissions.create({ kind: "consent", firstName: "Анна", consentGranted: false })).rejects.toThrow("Consent is required");
  });

  it("does not expose the admin list to ordinary users", async () => {
    const caller = appRouter.createCaller(baseContext("user"));
    await expect(caller.submissions.list()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
