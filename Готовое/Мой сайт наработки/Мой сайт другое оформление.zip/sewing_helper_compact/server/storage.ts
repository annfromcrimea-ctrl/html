import { GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { ENV } from "./_core/env";

const YANDEX_ENDPOINT = ENV.yandexStorageEndpoint || "https://storage.yandexcloud.net";
const YANDEX_REGION = ENV.yandexStorageRegion || "ru-central1";

function getForgeConfig() {
  const forgeUrl = ENV.forgeApiUrl;
  const forgeKey = ENV.forgeApiKey;
  if (!forgeUrl || !forgeKey) {
    throw new Error(
      "Storage config missing: set BUILT_IN_FORGE_API_URL and BUILT_IN_FORGE_API_KEY",
    );
  }
  return { forgeUrl: forgeUrl.replace(/\/+$/, ""), forgeKey };
}

function getYandexClient() {
  if (!ENV.yandexStorageBucket || !ENV.yandexStorageAccessKeyId || !ENV.yandexStorageSecretAccessKey) {
    return null;
  }
  return new S3Client({
    region: YANDEX_REGION,
    endpoint: YANDEX_ENDPOINT,
    forcePathStyle: true,
    credentials: {
      accessKeyId: ENV.yandexStorageAccessKeyId,
      secretAccessKey: ENV.yandexStorageSecretAccessKey,
    },
  });
}

export function getStorageProvider(): "yandex" | "manus" {
  return getYandexClient() ? "yandex" : "manus";
}

function normalizeKey(relKey: string): string {
  return relKey.replace(/^\/+/, "");
}

const MAX_UPLOAD_BYTES = 25 * 1024 * 1024;
const SAFE_MIME_PREFIXES = ["image/", "text/", "audio/", "video/"];
const SAFE_MIME_TYPES = new Set([
  "application/pdf",
  "application/json",
  "application/zip",
  "application/octet-stream",
]);

export function validateUpload(
  data: Buffer | Uint8Array | string,
  contentType: string,
  maxBytes = MAX_UPLOAD_BYTES,
): void {
  const size = typeof data === "string" ? Buffer.byteLength(data) : data.byteLength;
  if (size > maxBytes) {
    throw new Error(`Upload exceeds maximum size of ${maxBytes} bytes`);
  }
  const normalizedType = contentType.trim().toLowerCase();
  if (!normalizedType || (!SAFE_MIME_TYPES.has(normalizedType) && !SAFE_MIME_PREFIXES.some(prefix => normalizedType.startsWith(prefix)))) {
    throw new Error(`MIME type is not allowed: ${contentType}`);
  }
}

function appendHashSuffix(relKey: string): string {
  const hash = crypto.randomUUID().replace(/-/g, "").slice(0, 8);
  const lastDot = relKey.lastIndexOf(".");
  if (lastDot === -1) return `${relKey}_${hash}`;
  return `${relKey.slice(0, lastDot)}_${hash}${relKey.slice(lastDot)}`;
}

async function storagePutManus(key: string, data: Buffer | Uint8Array | string, contentType: string) {
  const { forgeUrl, forgeKey } = getForgeConfig();
  const presignUrl = new URL("v1/storage/presign/put", forgeUrl + "/");
  presignUrl.searchParams.set("path", key);
  const presignResp = await fetch(presignUrl, {
    headers: { Authorization: `Bearer ${forgeKey}` },
  });
  if (!presignResp.ok) {
    const msg = await presignResp.text().catch(() => presignResp.statusText);
    throw new Error(`Storage presign failed (${presignResp.status}): ${msg}`);
  }
  const { url: s3Url } = (await presignResp.json()) as { url: string };
  if (!s3Url) throw new Error("Forge returned empty presign URL");
  const blob = typeof data === "string" ? new Blob([data], { type: contentType }) : new Blob([data as any], { type: contentType });
  const uploadResp = await fetch(s3Url, {
    method: "PUT",
    headers: { "Content-Type": contentType },
    body: blob,
  });
  if (!uploadResp.ok) throw new Error(`Storage upload to S3 failed (${uploadResp.status})`);
  return { key, url: `/manus-storage/${key}` };
}

export async function storagePut(
  relKey: string,
  data: Buffer | Uint8Array | string,
  contentType = "application/octet-stream",
): Promise<{ key: string; url: string }> {
  validateUpload(data, contentType);
  const key = appendHashSuffix(normalizeKey(relKey));
  const client = getYandexClient();

  if (!client) return storagePutManus(key, data, contentType);

  const body = typeof data === "string" ? Buffer.from(data) : Buffer.from(data);
  await client.send(new PutObjectCommand({
    Bucket: ENV.yandexStorageBucket,
    Key: key,
    Body: body,
    ContentType: contentType,
    ServerSideEncryption: "AES256",
  }));
  return { key, url: await storageGetSignedUrl(key) };
}

export async function storageGet(relKey: string): Promise<{ key: string; url: string }> {
  const key = normalizeKey(relKey);
  return { key, url: await storageGetSignedUrl(key) };
}

export async function storageGetSignedUrl(relKey: string): Promise<string> {
  const key = normalizeKey(relKey);
  const client = getYandexClient();
  if (client) {
    return getSignedUrl(client, new GetObjectCommand({ Bucket: ENV.yandexStorageBucket, Key: key }), { expiresIn: 900 });
  }

  const { forgeUrl, forgeKey } = getForgeConfig();
  const getUrl = new URL("v1/storage/presign/get", forgeUrl + "/");
  getUrl.searchParams.set("path", key);
  const resp = await fetch(getUrl, { headers: { Authorization: `Bearer ${forgeKey}` } });
  if (!resp.ok) {
    const msg = await resp.text().catch(() => resp.statusText);
    throw new Error(`Storage signed URL failed (${resp.status}): ${msg}`);
  }
  const { url } = (await resp.json()) as { url: string };
  return url;
}
