# Деплой проекта на Yandex Compute Cloud

## Что потребуется

Нужны аккаунт в [Yandex Cloud](https://console.yandex.cloud/), платёжный аккаунт, доменное имя, SSH-ключ и реквизиты Managed MySQL. Для хранения файлов дополнительно создайте приватный бакет Object Storage. Не передавайте приватный ключ SSH, пароли и access key в чат или Git.

## 1. Создайте сеть и виртуальную машину

В каталоге Yandex Cloud создайте VPC-сеть и подсеть в зоне доступности, например `ru-central1-a`. Создайте VM с Ubuntu LTS, публичным IPv4 и диском, достаточным для проекта и логов. В группе безопасности разрешите входящие подключения только на TCP 22 с вашего IP, TCP 80 и TCP 443 из интернета. Порт 3000 наружу не открывайте: приложение должно быть доступно через Nginx.

Добавьте SSH-ключ при создании VM. Подключение выполняйте так:

```bash
ssh -i ~/.ssh/id_ed25519 ubuntu@PUBLIC_IP
```

## 2. Установите системные зависимости

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y ca-certificates curl git nginx unzip
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs
sudo npm install -g pnpm pm2
node --version
pnpm --version
```

Используйте актуальную LTS-версию Node.js, совместимую с проектом. Если политика организации запрещает внешний installer, установите Node.js из одобренного внутреннего репозитория.

## 3. Разместите проект

Загрузите ZIP в VM или клонируйте репозиторий. Например:

```bash
sudo mkdir -p /opt/sewing-helper
sudo chown -R ubuntu:ubuntu /opt/sewing-helper
cd /opt/sewing-helper
unzip sewing_helper_compact_final_3d.zip
cd sewing_helper_compact
pnpm install --frozen-lockfile
```

Не копируйте в VM локальный `.env` из рабочего компьютера. Создайте production-окружение непосредственно на сервере.

## 4. Создайте Managed MySQL

В консоли создайте кластер [Managed Service for MySQL](https://yandex.cloud/en/docs/managed-mysql/quickstart) в том же облаке и VPC. Создайте отдельную базу и пользователя с минимальными правами. Разрешите подключение из подсети VM, включите TLS и сформируйте `DATABASE_URL` с адресом кластера, базой, пользователем и паролем.

## 5. Настройте окружение

В каталоге проекта создайте `.env` с правами только для владельца:

```bash
chmod 600 .env
nano .env
```

Минимально необходимы:

```env
NODE_ENV=production
PORT=3000
DATABASE_URL=mysql://USER:PASSWORD@MYSQL_HOST:3306/DATABASE?ssl=true
JWT_SECRET=длинное_случайное_значение
VITE_APP_TITLE=Учебный маршрут
```

Для приватного Object Storage добавьте:

```env
YANDEX_STORAGE_ENDPOINT=https://storage.yandexcloud.net
YANDEX_STORAGE_BUCKET=ИМЯ_ПРИВАТНОГО_БАКЕТА
YANDEX_STORAGE_ACCESS_KEY_ID=ACCESS_KEY_ID
YANDEX_STORAGE_SECRET_ACCESS_KEY=SECRET_ACCESS_KEY
YANDEX_STORAGE_REGION=ru-central1
```

OAuth-переменные проекта также должны быть заданы в production-окружении, если используется вход администратора. Не помещайте `.env` в архив, Git или каталог `client`.

## 6. Выполните миграции и сборку

```bash
cd /opt/sewing-helper/sewing_helper_compact
pnpm check
pnpm test
pnpm build
```

Миграции схемы базы выполняйте согласно принятому процессу проекта. Перед миграцией сделайте резервную копию базы и убедитесь, что таблица заявок и поле статуса созданы.

## 7. Запустите Node.js-приложение

```bash
pm2 start dist/index.js --name sewing-helper
pm2 save
pm2 startup
```

Выполните команду `pm2 startup`, которую напечатает система, затем повторите `pm2 save`. Проверьте:

```bash
pm2 status
pm2 logs sewing-helper --lines 100
curl -I http://127.0.0.1:3000/
```

## 8. Настройте Nginx

Создайте `/etc/nginx/sites-available/sewing-helper`:

```nginx
server {
    listen 80;
    server_name example.ru www.example.ru;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

Замените `example.ru` на ваш домен и включите конфигурацию:

```bash
sudo ln -s /etc/nginx/sites-available/sewing-helper /etc/nginx/sites-enabled/sewing-helper
sudo nginx -t
sudo systemctl reload nginx
```

## 9. Подключите DNS и HTTPS

Создайте A-записи домена на публичный IP VM. После обновления DNS выпустите сертификат через [Yandex Certificate Manager](https://yandex.cloud/en/docs/certificate-manager/) или другой согласованный российский сервис сертификатов. Добавьте HTTPS-конфигурацию Nginx, перенаправление с HTTP на HTTPS и проверьте:

```bash
curl -I https://example.ru/
curl -I https://example.ru/admin
```

Публичный IP VM лучше заменить на статический, чтобы адрес не изменился после перезапуска.

## 10. Проверка после публикации

Проверьте публичную страницу на компьютере и телефоне. Отправьте тестовую заявку, откройте `/admin`, войдите пользователем с ролью `admin`, найдите запись и измените статус на **«Обработана»**. Выполните тестовую загрузку файла и убедитесь, что объект появился в приватном бакете, а приложение выдало временную signed URL.

## Диагностика

| Симптом | Проверка |
|---|---|
| VM не доступна по SSH | Проверьте публичный IP, группу безопасности, порт 22 и разрешённый IP источника. Убедитесь, что используете правильный приватный ключ и пользователя `ubuntu`. |
| Nginx показывает 502 | Выполните `pm2 status`, `pm2 logs sewing-helper` и `curl http://127.0.0.1:3000/`. Проверьте, что Node-процесс слушает только локальный порт 3000. |
| Домен не открывается | Проверьте A-записи через DNS-проверку, IP VM и `sudo nginx -t`. Подождите обновления DNS. |
| Сертификат не выпускается | Убедитесь, что домен указывает на VM, HTTP/HTTPS разрешены в группе безопасности, а проверочная запись сертификата создана корректно. |
| Ошибка подключения к MySQL | Проверьте `DATABASE_URL`, TLS, адрес кластера, пользователя, пароль, VPC и список разрешённых сетей кластера. Не открывайте MySQL всему интернету. |
| Ошибка миграции | Сделайте резервную копию, проверьте текущую схему и журнал миграций. Не удаляйте таблицы с заявками без отдельной резервной копии. |
| `Storage config missing` | Проверьте все пять переменных Yandex Storage и перезапустите `pm2 restart sewing-helper --update-env`. |
| `403 AccessDenied` при загрузке | Проверьте IAM-права сервисного аккаунта на конкретный бакет, имя бакета и правильность access key. |
| Файл загружается локально | Убедитесь, что переменные Object Storage доступны именно процессу PM2, затем выполните `pm2 restart sewing-helper --update-env`. |
| Форма не отправляется | Откройте консоль браузера, проверьте `/api/trpc`, затем посмотрите `pm2 logs sewing-helper`. Проверьте авторизацию, миграции и доступ к базе. |
| `/admin` не открывает журнал | Проверьте вход пользователя, поле `role=admin` в таблице пользователей и серверный ответ процедуры списка заявок. |

## Обновление проекта

Перед обновлением сохраните резервную копию базы и текущую конфигурацию. Загрузите новую версию, выполните `pnpm install --frozen-lockfile`, `pnpm check`, `pnpm test`, `pnpm build`, затем перезапустите `pm2 restart sewing-helper --update-env`. После обновления повторите тест формы, `/admin`, статуса заявки и Object Storage.

## Безопасность

Используйте SSH-ключи вместо паролей, минимальные IAM-роли, приватный бакет, закрытый MySQL, HTTPS и регулярные резервные копии. Не публикуйте `.env`, секретные ключи и персональные данные в репозитории или архиве. Юридические тексты согласий и порядок обработки персональных данных проверьте у профильного специалиста.
