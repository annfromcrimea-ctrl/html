import { listSubmissions } from "./db";

function csvCell(value: unknown) {
  return `"${String(value ?? "").replaceAll('"', '""')}"`;
}

export async function exportConsentsToYandexDisk() {
  const token = process.env.YANDEX_DISK_OAUTH_TOKEN;
  const folder = (process.env.YANDEX_DISK_FOLDER || "app-exports").replace(/^\/+|\/+$/g, "");
  if (!token) return { configured: false as const, message: "YANDEX_DISK_OAUTH_TOKEN не настроен" };

  const rows = (await listSubmissions()).filter((row) => row.kind === "consent");
  const header = ["id", "createdAt", "firstName", "lastName", "email", "consentGranted", "documentVersion", "status"].join(",");
  const body = rows.map((row) => [row.id, row.createdAt.toISOString(), row.firstName, row.lastName, row.email, row.consentGranted, row.documentVersion, row.status].map(csvCell).join(",")).join("\n");
  const csv = `\ufeff${header}\n${body}\n`;
  const fileName = `consents-${new Date().toISOString().slice(0, 10)}.csv`;
  const path = `${folder}/${fileName}`;
  const apiUrl = `https://cloud-api.yandex.net/v1/disk/resources/upload?path=${encodeURIComponent(path)}&overwrite=true`;
  const uploadInfo = await fetch(apiUrl, { headers: { Authorization: `OAuth ${token}` } });
  if (!uploadInfo.ok) throw new Error(`Yandex Disk upload URL error: ${uploadInfo.status}`);
  const { href } = await uploadInfo.json() as { href?: string };
  if (!href) throw new Error("Yandex Disk did not return upload URL");
  const uploaded = await fetch(href, { method: "PUT", headers: { "Content-Type": "text/csv; charset=utf-8" }, body: csv });
  if (!uploaded.ok) throw new Error(`Yandex Disk upload error: ${uploaded.status}`);
  return { configured: true as const, fileName, path, count: rows.length };
}
