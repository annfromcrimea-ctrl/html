import { describe, expect, it, vi, afterEach } from "vitest";
import { exportConsentsToYandexDisk } from "./yandexDisk";
import * as db from "./db";

describe("yandex disk export", () => {
  afterEach(() => {
    delete process.env.YANDEX_DISK_OAUTH_TOKEN;
    vi.restoreAllMocks();
  });

  it("returns a safe configuration message when token is absent", async () => {
    vi.spyOn(db, "listSubmissions").mockResolvedValue([]);
    await expect(exportConsentsToYandexDisk()).resolves.toEqual({ configured: false, message: "YANDEX_DISK_OAUTH_TOKEN не настроен" });
  });

  it("requests an upload URL and sends a CSV file when configured", async () => {
    process.env.YANDEX_DISK_OAUTH_TOKEN = "test-token";
    vi.spyOn(db, "listSubmissions").mockResolvedValue([{
      id: 7, kind: "consent", firstName: "Анна", lastName: "Тест", email: "anna@example.com", meetingFormat: null, comment: null,
      consentGranted: 1, documentVersion: "1.2", status: "new", createdAt: new Date("2026-08-27T00:00:00Z"),
    }]);
    const fetchMock = vi.spyOn(globalThis, "fetch").mockResolvedValueOnce(new Response(JSON.stringify({ href: "https://upload.example" }), { status: 200 })).mockResolvedValueOnce(new Response("", { status: 201 }));
    await expect(exportConsentsToYandexDisk()).resolves.toMatchObject({ configured: true, count: 1, fileName: "consents-2026-08-27.csv" });
    expect(fetchMock).toHaveBeenCalledTimes(2);
    expect(fetchMock.mock.calls[1][1]).toMatchObject({ method: "PUT" });
  });
});
