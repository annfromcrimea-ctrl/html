import { afterEach, describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import * as db from "./db";
import type { TrpcContext } from "./_core/context";

const context = (): TrpcContext => ({
  user: null,
  req: {} as TrpcContext["req"],
  res: {} as TrpcContext["res"],
});

describe("submission directions", () => {
  afterEach(() => vi.restoreAllMocks());

  it("stores a Spotlight direction", async () => {
    const create = vi.spyOn(db, "createSubmission").mockResolvedValue({ id: 21 });
    await appRouter.createCaller(context()).submissions.create({ kind: "signup", firstName: "Ирина", email: "irina@example.com", meetingFormat: "Spotlight 2 · подписка", direction: "spotlight2", consentGranted: false });
    expect(create).toHaveBeenCalledWith(expect.objectContaining({ direction: "spotlight2", meetingFormat: "Spotlight 2 · подписка" }));
  });

  it("stores a studio direction", async () => {
    const create = vi.spyOn(db, "createSubmission").mockResolvedValue({ id: 22 });
    await appRouter.createCaller(context()).submissions.create({ kind: "signup", firstName: "Олег", email: "oleg@example.com", meetingFormat: "студия · иностранные языки и развитие", direction: "studio", consentGranted: false });
    expect(create).toHaveBeenCalledWith(expect.objectContaining({ direction: "studio", meetingFormat: "студия · иностранные языки и развитие" }));
  });
});

  it("stores other for an unspecified direction", async () => {
    const create = vi.spyOn(db, "createSubmission").mockResolvedValue({ id: 23 });
    await appRouter.createCaller(context()).submissions.create({ kind: "signup", firstName: "Мария", email: "maria@example.com", meetingFormat: "Пока не определился(ась)", direction: "other", consentGranted: false });
    expect(create).toHaveBeenCalledWith(expect.objectContaining({ direction: "other", meetingFormat: "Пока не определился(ась)" }));
  });
