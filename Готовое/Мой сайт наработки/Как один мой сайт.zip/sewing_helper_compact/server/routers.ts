import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import { createSubmission, listSubmissions, updateSubmissionStatus } from "./db";
import { createSiteLink, deleteSiteLink, listAllSiteLinks, listSiteLinks, listSiteSettings, updateSiteLink, upsertSiteSetting } from "./siteContent";
import { exportConsentsToYandexDisk } from "./yandexDisk";

const safeLinkUrl = z.string().trim().min(1).max(1000).refine((value) => value.startsWith("#") || /^https?:\/\//i.test(value), "Разрешены только якоря и HTTP/HTTPS-ссылки");

const submissionInput = z.object({
  kind: z.enum(["consent", "signup"]),
  firstName: z.string().trim().min(1).max(120),
  lastName: z.string().trim().max(120).optional(),
  email: z.string().trim().email().max(320).optional().or(z.literal("")),
  meetingFormat: z.string().max(128).optional(),
  direction: z.enum(["spotlight1", "spotlight2", "spotlight3", "spotlight4", "studio", "other"]).default("other"),
  comment: z.string().max(5000).optional(),
  consentGranted: z.boolean().default(false),
  documentVersion: z.string().max(32).optional(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(({ ctx }) => ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  site: router({
    publicLinks: publicProcedure.query(() => listSiteLinks()),
    settings: publicProcedure.query(() => listSiteSettings()),
    adminLinks: adminProcedure.query(() => listAllSiteLinks()),
    saveSetting: adminProcedure.input(z.object({ settingKey: z.string().trim().min(1).max(80), settingValue: z.string().max(10000) })).mutation(({ input }) => upsertSiteSetting(input.settingKey, input.settingValue)),
    createLink: adminProcedure.input(z.object({ label: z.string().trim().min(1).max(160), url: safeLinkUrl, kind: z.enum(["spotlight", "craft", "studio", "legal", "other"]), isVisible: z.number().int().min(0).max(1).default(1), sortOrder: z.number().int().default(0) })).mutation(({ input }) => createSiteLink(input)),
    updateLink: adminProcedure.input(z.object({ id: z.number().int().positive(), label: z.string().trim().min(1).max(160).optional(), url: safeLinkUrl.optional(), kind: z.enum(["spotlight", "craft", "studio", "legal", "other"]).optional(), isVisible: z.number().int().min(0).max(1).optional(), sortOrder: z.number().int().optional() })).mutation(({ input }) => { const { id, ...changes } = input; return updateSiteLink(id, changes); }),
    deleteLink: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input }) => deleteSiteLink(input.id)),
  }),
  submissions: router({
    create: publicProcedure.input(submissionInput).mutation(async ({ input }) => {
      if (input.kind === "consent" && !input.consentGranted) throw new Error("Consent is required");
      return createSubmission({ ...input, email: input.email || null, consentGranted: input.consentGranted ? 1 : 0 });
    }),
    list: adminProcedure.query(() => listSubmissions()),
    updateStatus: adminProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(["new", "processed", "archived"]) })).mutation(({ input }) => updateSubmissionStatus(input.id, input.status)),
    exportConsents: adminProcedure.mutation(() => exportConsentsToYandexDisk()),
  }),
});

export type AppRouter = typeof appRouter;
