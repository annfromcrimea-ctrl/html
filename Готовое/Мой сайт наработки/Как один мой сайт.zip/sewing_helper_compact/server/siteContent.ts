import { asc, eq } from "drizzle-orm";
import { siteLinks, siteSettings, InsertSiteLink } from "../drizzle/schema";
import { getDb } from "./db";

export async function listSiteLinks() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(siteLinks).where(eq(siteLinks.isVisible, 1)).orderBy(asc(siteLinks.sortOrder), asc(siteLinks.id));
}

export async function listAllSiteLinks() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(siteLinks).orderBy(asc(siteLinks.sortOrder), asc(siteLinks.id));
}

export async function listSiteSettings() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(siteSettings).orderBy(asc(siteSettings.settingKey));
}

export async function upsertSiteSetting(settingKey: string, settingValue: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(siteSettings).values({ settingKey, settingValue }).onDuplicateKeyUpdate({ set: { settingValue } });
  return { settingKey, settingValue };
}

export async function createSiteLink(input: Omit<InsertSiteLink, "id" | "updatedAt">) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(siteLinks).values(input);
  return { id: Number(result[0].insertId) };
}

export async function updateSiteLink(id: number, input: Partial<Omit<InsertSiteLink, "id" | "updatedAt">>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(siteLinks).set(input).where(eq(siteLinks.id, id));
  return { id };
}

export async function deleteSiteLink(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(siteLinks).where(eq(siteLinks.id, id));
  return { id };
}
