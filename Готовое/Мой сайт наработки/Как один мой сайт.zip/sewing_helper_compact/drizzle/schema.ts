import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, index } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const submissions = mysqlTable("submissions", {
  id: int("id").autoincrement().primaryKey(),
  kind: mysqlEnum("kind", ["consent", "signup"]).notNull(),
  firstName: varchar("firstName", { length: 120 }).notNull(),
  lastName: varchar("lastName", { length: 120 }),
  email: varchar("email", { length: 320 }),
  meetingFormat: varchar("meetingFormat", { length: 64 }),
  direction: mysqlEnum("direction", ["spotlight1", "spotlight2", "spotlight3", "spotlight4", "studio", "other"]).default("other").notNull(),
  comment: text("comment"),
  consentGranted: int("consentGranted").default(0).notNull(),
  documentVersion: varchar("documentVersion", { length: 32 }),
  status: mysqlEnum("status", ["new", "processed", "archived"]).default("new").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  createdAtIdx: index("submissions_createdAt_idx").on(table.createdAt),
  kindIdx: index("submissions_kind_idx").on(table.kind),
}));

export const siteSettings = mysqlTable("site_settings", {
  id: int("id").autoincrement().primaryKey(),
  settingKey: varchar("settingKey", { length: 80 }).notNull().unique(),
  settingValue: text("settingValue").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const siteLinks = mysqlTable("site_links", {
  id: int("id").autoincrement().primaryKey(),
  label: varchar("label", { length: 160 }).notNull(),
  url: varchar("url", { length: 1000 }).notNull(),
  kind: mysqlEnum("kind", ["spotlight", "craft", "studio", "legal", "other"]).default("other").notNull(),
  isVisible: int("isVisible").default(1).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  sortIdx: index("site_links_sort_idx").on(table.sortOrder),
}));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Submission = typeof submissions.$inferSelect;
export type InsertSubmission = typeof submissions.$inferInsert;
export type SiteSetting = typeof siteSettings.$inferSelect;
export type InsertSiteSetting = typeof siteSettings.$inferInsert;
export type SiteLink = typeof siteLinks.$inferSelect;
export type InsertSiteLink = typeof siteLinks.$inferInsert;
