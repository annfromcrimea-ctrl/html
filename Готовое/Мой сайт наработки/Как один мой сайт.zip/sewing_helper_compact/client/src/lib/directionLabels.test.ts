import { describe, expect, it } from "vitest";
import { getDirectionLabel } from "./directionLabels";

describe("direction labels", () => {
  it("renders other as Другое", () => {
    expect(getDirectionLabel("other")).toBe("Другое");
    expect(getDirectionLabel("unknown-direction")).toBe("Другое");
  });

  it("renders Spotlight and studio labels", () => {
    expect(getDirectionLabel("spotlight4")).toBe("Spotlight 4");
    expect(getDirectionLabel("studio")).toBe("Студия");
  });
});
