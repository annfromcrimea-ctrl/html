export const directionLabel: Record<string, string> = {
  spotlight1: "Spotlight 1",
  spotlight2: "Spotlight 2",
  spotlight3: "Spotlight 3",
  spotlight4: "Spotlight 4",
  studio: "Студия",
  other: "Другое",
};

export function getDirectionLabel(direction: string | null | undefined) {
  return directionLabel[direction ?? "other"] ?? "Другое";
}
