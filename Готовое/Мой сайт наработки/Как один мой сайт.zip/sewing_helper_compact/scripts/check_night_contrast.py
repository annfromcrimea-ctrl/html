def channel(value):
    value /= 255
    return value / 12.92 if value <= 0.04045 else ((value + 0.055) / 1.055) ** 2.4

def luminance(hex_color):
    rgb = [int(hex_color[i:i + 2], 16) for i in (1, 3, 5)]
    r, g, b = [channel(v) for v in rgb]
    return 0.2126 * r + 0.7152 * g + 0.0722 * b

def contrast(foreground, background):
    a, b = luminance(foreground), luminance(background)
    return (max(a, b) + 0.05) / (min(a, b) + 0.05)

pairs = [
    ("--ink", "#c8e5d2", "#17201d"),
    ("--ink-soft", "#9bc4a9", "#17201d"),
    ("--green", "#8fd6a5", "#17201d"),
    ("primary button", "#132219", "#64c987"),
]
for name, foreground, background in pairs:
    print(f"{name}: {contrast(foreground, background):.2f}:1")
