const channel = value => { const v = value / 255; return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; };
const luminance = hex => { const rgb = [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16)); const [r, g, b] = rgb.map(channel); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
const contrast = (fg, bg) => { const a = luminance(fg), b = luminance(bg); return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05); };
for (const [name, fg, bg] of [["--ink", "#c8e5d2", "#17201d"], ["--ink-soft", "#9bc4a9", "#17201d"], ["--green", "#8fd6a5", "#17201d"], ["primary button", "#132219", "#64c987"]]) console.log(`${name}: ${contrast(fg, bg).toFixed(2)}:1`);
