export type ScheduleEvent = {
  id: string;
  date: string;
  dateKey: string;
  time: string;
  title: string;
  type: "lesson" | "review" | "exam";
  duration: string;
  reminderMinutes: number;
};

export function displayDateFor(dateKey: string) {
  return dateKey ? new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "long" }).format(new Date(`${dateKey}T12:00:00`)) : "";
}

export function createScheduleEvent(input: Omit<Partial<ScheduleEvent>, "date"> & { id: string; title: string; dateKey: string }): ScheduleEvent {
  return { id: input.id, title: input.title, dateKey: input.dateKey, date: displayDateFor(input.dateKey), time: input.time ?? "16:00", type: input.type ?? "lesson", duration: input.duration ?? "60 мин", reminderMinutes: input.reminderMinutes ?? 30 };
}

export function updateScheduleEvent(current: ScheduleEvent, patch: Partial<ScheduleEvent>) {
  const next = { ...current, ...patch };
  return patch.dateKey ? { ...next, dateKey: patch.dateKey, date: displayDateFor(patch.dateKey) } : { ...next, date: displayDateFor(next.dateKey) };
}
