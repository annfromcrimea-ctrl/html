# Mobile Teacher and Invite Check

The `/teacher` route renders correctly at 390px wide: header, add-student CTA, summary cards, focus card, and empty state stack without clipping. For an authenticated teacher/admin with a selected student, the workspace includes selector-driven editing for homework title and subject, existing comment edit/delete, new teacher replies, attachment upload/delete, and schedule title, date, time, duration, and reminder changes. The current preview database contains no teacher student records, so the screenshot verifies the route and responsive shell; action-level persistence must be exercised after creating the first student from the portal.

The requested token `39f3fc774c2e9bbefc991ec0ac1a8385` is not present in the current database, so its invite route correctly shows an unavailable-invite state rather than pretending that a student account exists.
