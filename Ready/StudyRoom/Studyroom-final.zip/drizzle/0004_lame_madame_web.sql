CREATE TABLE `teacher_students` (
	`id` int AUTO_INCREMENT NOT NULL,
	`teacherId` int NOT NULL,
	`dashboardId` int,
	`name` varchar(120) NOT NULL,
	`email` varchar(320),
	`inviteToken` varchar(48) NOT NULL,
	`status` varchar(16) NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `teacher_students_id` PRIMARY KEY(`id`),
	CONSTRAINT `teacher_students_inviteToken_unique` UNIQUE(`inviteToken`)
);
--> statement-breakpoint
CREATE INDEX `teacher_students_teacher_idx` ON `teacher_students` (`teacherId`);--> statement-breakpoint
CREATE INDEX `teacher_students_dashboard_idx` ON `teacher_students` (`dashboardId`);