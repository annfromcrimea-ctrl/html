import { index, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "teacher", "admin", "owner"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const studentDashboards = mysqlTable("student_dashboards", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  shareToken: varchar("shareToken", { length: 48 }).notNull().unique(),
  title: varchar("title", { length: 160 }).notNull().default("Мой учебный кабинет"),
  studentName: varchar("studentName", { length: 120 }).notNull().default("Новый ученик"),
  data: text("data").notNull(),
  scheduleCronTaskUid: varchar("scheduleCronTaskUid", { length: 65 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({ scheduleCronTaskUidIdx: index("student_dashboards_schedule_cron_uid_idx").on(table.scheduleCronTaskUid) }));

export const teacherStudents = mysqlTable("teacher_students", {
  id: int("id").autoincrement().primaryKey(),
  teacherId: int("teacherId").notNull(),
  assignedTeacherId: int("assignedTeacherId"),
  dashboardId: int("dashboardId"),
  name: varchar("name", { length: 120 }).notNull(),
  email: varchar("email", { length: 320 }),
  inviteToken: varchar("inviteToken", { length: 48 }).notNull().unique(),
  status: varchar("status", { length: 16 }).notNull().default("active"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({ teacherIdx: index("teacher_students_teacher_idx").on(table.teacherId), assignedTeacherIdx: index("teacher_students_assigned_teacher_idx").on(table.assignedTeacherId), dashboardIdx: index("teacher_students_dashboard_idx").on(table.dashboardId) }));

export const teacherInvites = mysqlTable("teacher_invites", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  teacherUserId: int("teacherUserId"),
  name: varchar("name", { length: 120 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  role: varchar("role", { length: 24 }).notNull().default("teacher"),
  inviteToken: varchar("inviteToken", { length: 48 }).notNull().unique(),
  status: varchar("status", { length: 16 }).notNull().default("pending"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => ({ ownerIdx: index("teacher_invites_owner_idx").on(table.ownerId), tokenIdx: index("teacher_invites_token_idx").on(table.inviteToken) }));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type StudentDashboard = typeof studentDashboards.$inferSelect;
export type InsertStudentDashboard = typeof studentDashboards.$inferInsert;
