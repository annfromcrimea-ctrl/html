CREATE TABLE `teacher_invites` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`teacherUserId` int,
	`name` varchar(120) NOT NULL,
	`email` varchar(320) NOT NULL,
	`role` varchar(24) NOT NULL DEFAULT 'teacher',
	`inviteToken` varchar(48) NOT NULL,
	`status` varchar(16) NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `teacher_invites_id` PRIMARY KEY(`id`),
	CONSTRAINT `teacher_invites_inviteToken_unique` UNIQUE(`inviteToken`)
);
--> statement-breakpoint
ALTER TABLE `teacher_students` ADD `assignedTeacherId` int;--> statement-breakpoint
CREATE INDEX `teacher_invites_owner_idx` ON `teacher_invites` (`ownerId`);--> statement-breakpoint
CREATE INDEX `teacher_invites_token_idx` ON `teacher_invites` (`inviteToken`);--> statement-breakpoint
CREATE INDEX `teacher_students_assigned_teacher_idx` ON `teacher_students` (`assignedTeacherId`);