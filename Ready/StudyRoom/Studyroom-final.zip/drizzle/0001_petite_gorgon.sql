CREATE TABLE `student_dashboards` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`shareToken` varchar(48) NOT NULL,
	`title` varchar(160) NOT NULL DEFAULT 'Мой учебный кабинет',
	`studentName` varchar(120) NOT NULL DEFAULT 'Новый ученик',
	`data` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `student_dashboards_id` PRIMARY KEY(`id`),
	CONSTRAINT `student_dashboards_shareToken_unique` UNIQUE(`shareToken`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` varchar(16) NOT NULL DEFAULT 'user';