import mysql from "mysql2/promise";
const url = process.env.DATABASE_URL;
if (!url) process.exit(0);
const connection = await mysql.createConnection(url);
const [rows] = await connection.query("SELECT id, shareToken FROM student_dashboards ORDER BY id DESC LIMIT 5");
console.log(JSON.stringify(rows));
await connection.end();
