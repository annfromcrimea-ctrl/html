import { describe, expect, it } from "vitest";
import { canAccessDashboardByRole } from "./db";

describe("school team access policy", () => {
  it("allows owner and admin access regardless of assignment", () => {
    expect(canAccessDashboardByRole(10, "owner", 99, null)).toBe(true);
    expect(canAccessDashboardByRole(10, "admin", 99, null)).toBe(true);
  });

  it("allows a teacher only when explicitly assigned", () => {
    expect(canAccessDashboardByRole(10, "teacher", 99, 10)).toBe(true);
    expect(canAccessDashboardByRole(10, "teacher", 99, null)).toBe(false);
    expect(canAccessDashboardByRole(10, "teacher", 99, 11)).toBe(false);
  });

  it("keeps unrelated users outside the school workspace", () => {
    expect(canAccessDashboardByRole(10, "user", 99, 10)).toBe(false);
    expect(canAccessDashboardByRole(10, "user", 10, null)).toBe(true);
  });
});
