import { describe, expect, it } from "vitest";
import { appendHomeworkComment, canManageSchoolTeam, dashboardDataSchema, isReminderDueSoon, removeDashboardAttachment, scheduleOnDate, setActiveProfile, teacherInviteInputSchema, updateSchema } from "./routers";
import { createScheduleEvent, displayDateFor, updateScheduleEvent } from "../shared/schedule";

const validData = {
  profiles: [],
  activeProfileId: "",
  reminderNotice: "",
  topics: [{ id: "t1", title: "Алгебра", description: "Практика", status: "active" as const, color: "violet", attachments: [] }],
  homework: [{ id: "h1", title: "Задачи", subject: "Математика", dueDate: "Завтра", dueDateKey: "", status: "pending" as const, priority: "high" as const, attachments: [], comments: [] }],
  schedule: [{ id: "s1", date: "Сегодня", time: "16:00", title: "Урок", type: "lesson" as const, duration: "60 мин", reminderMinutes: 30, dateKey: "" }],
  notes: [{ id: "n1", title: "Фокус", content: "Повторить", date: "Сегодня", tone: "cream" as const }],
  progress: { overall: 72, streak: 5, completedLessons: 18, weeklyGoal: 4 },
};

describe("student dashboard contracts", () => {
  it("allows only school admins to manage the teacher team", () => {
    expect(canManageSchoolTeam("owner")).toBe(true);
    expect(canManageSchoolTeam("admin")).toBe(true);
    expect(canManageSchoolTeam("teacher")).toBe(false);
    expect(canManageSchoolTeam("user")).toBe(false);
  });

  it("validates teacher invite roles and email", () => {
    expect(teacherInviteInputSchema.parse({ name: "Мария", email: "maria@example.com" }).role).toBe("teacher");
    expect(() => teacherInviteInputSchema.parse({ name: "", email: "bad" })).toThrow();
  });
  it("recognizes structured dates for reminder delivery", () => {
    const today = new Date().toISOString().slice(0, 10);
    expect(isReminderDueSoon(today)).toBe(true);
    expect(isReminderDueSoon("2000-01-01")).toBe(false);
    expect(isReminderDueSoon("", "Завтра")).toBe(true);
  });

  it("switches only to an existing profile", () => {
    expect(setActiveProfile(dashboardDataSchema.parse(validData), "missing").activeProfileId).toBe("");
    const data = dashboardDataSchema.parse({ ...validData, profiles: [{ id: "p1", name: "Аня", role: "student", email: "" }] });
    expect(setActiveProfile(data, "p1").activeProfileId).toBe("p1");
  });

  it("removes a topic attachment without affecting other records", () => {
    const data = dashboardDataSchema.parse({ ...validData, topics: [{ ...validData.topics[0], attachments: [{ id: "a1", name: "file.pdf", url: "/file", mimeType: "application/pdf", size: 10 }] }] });
    const next = removeDashboardAttachment(data, "topics", "t1", "a1");
    expect(next.topics[0]?.attachments).toEqual([]);
  });

  it("creates a schedule event with date derived from dateKey", () => {
    const event = createScheduleEvent({ id: "s-create", title: "Урок", dateKey: "2026-08-27" });
    expect(event.dateKey).toBe("2026-08-27");
    expect(event.date).toBe(displayDateFor("2026-08-27"));
  });

  it("updates dateKey and automatically replaces the display date", () => {
    const event = createScheduleEvent({ id: "s-edit", title: "Урок", dateKey: "2026-08-27" });
    const updated = updateScheduleEvent(event, { dateKey: "2026-08-30" });
    expect(updated.dateKey).toBe("2026-08-30");
    expect(updated.date).toBe(displayDateFor("2026-08-30"));
  });

  it("keeps the display date and ISO dateKey together", () => {
    const data = dashboardDataSchema.parse({ ...validData, schedule: [{ ...validData.schedule[0], date: "27 августа", dateKey: "2026-08-27" }] });
    expect(data.schedule[0]?.date).toBe("27 августа");
    expect(scheduleOnDate(data, "2026-08-27")[0]?.date).toBe("27 августа");
  });

  it("places schedule records only on their matching ISO date", () => {
    const data = dashboardDataSchema.parse({ ...validData, schedule: [{ ...validData.schedule[0], dateKey: "2026-08-27" }, { ...validData.schedule[0], id: "s2", dateKey: "2026-08-28" }] });
    expect(scheduleOnDate(data, "2026-08-28").map(item => item.id)).toEqual(["s2"]);
  });

  it("appends a homework comment for the shared conversation", () => {
    const data = dashboardDataSchema.parse(validData);
    const next = appendHomeworkComment(data, "h1", { id: "c1", author: "Аня", role: "student", text: "Подскажите, пожалуйста, как решить задачу?", createdAt: new Date().toISOString() });
    expect(next.homework[0]?.comments).toHaveLength(1);
    expect(next.homework[0]?.comments[0]?.text).toContain("как решить");
  });

  it("accepts complete dashboard data for persistence", () => {
    expect(dashboardDataSchema.parse(validData)).toEqual(validData);
  });

  it("rejects unknown homework statuses", () => {
    const invalid = { ...validData, homework: [{ ...validData.homework[0], status: "in-review" }] };
    expect(() => dashboardDataSchema.parse(invalid)).toThrow();
  });

  it("requires a non-empty title and student name for shared-link updates", () => {
    expect(() => updateSchema.parse({ title: "", studentName: "Ученик", data: validData })).toThrow();
    expect(() => updateSchema.parse({ title: "Кабинет", studentName: "", data: validData })).toThrow();
    expect(updateSchema.parse({ title: "Кабинет", studentName: "Ученик", data: validData }).title).toBe("Кабинет");
  });
});

import { vi } from "vitest";

vi.mock("./_core/heartbeat", () => ({ createHeartbeatJob: vi.fn(async () => ({ taskUid: "task-123", nextExecutionAt: null })) }));
vi.mock("./storage", () => ({ storagePut: vi.fn(async () => ({ key: "dashboard/file.pdf", url: "/manus-storage/dashboard/file.pdf" })) }));
vi.mock("./db", () => ({
  createDashboard: vi.fn(async (input: { shareToken: string; title: string; studentName: string; data: string; ownerId: number }) => ({ id: 7, ...input, createdAt: new Date(), updatedAt: new Date() })),
  getDashboardByOwner: vi.fn(async () => undefined),
  getDashboardByToken: vi.fn(async (token: string) => ({ id: 7, ownerId: 1, shareToken: token, title: "Кабинет", studentName: "Ученик", data: JSON.stringify(validData), createdAt: new Date(), updatedAt: new Date() })),
  updateDashboard: vi.fn(async () => undefined),
}));

import { appRouter } from "./routers";

describe("shared dashboard procedures", () => {
  const ctx = { user: { id: 1, openId: "owner", role: "user", name: "Owner", email: "owner@example.com", loginMethod: "manus", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }, req: {}, res: {} } as never;

  it("creates a dashboard with a unique token", async () => {
    const result = await appRouter.createCaller(ctx).dashboard.create({ title: "Кабинет", studentName: "Ученик", data: validData });
    expect(result?.shareToken).toHaveLength(18);
  });

  it("enables one background reminder job for the owner", async () => {
    const { createHeartbeatJob } = await import("./_core/heartbeat");
    const caller = appRouter.createCaller({ ...ctx, req: { headers: { cookie: "app_session_id=session" } } } as never);
    const result = await caller.dashboard.enableReminders({ token: "shared-token-123" });
    expect(result.enabled).toBe(true);
    expect(createHeartbeatJob).toHaveBeenCalledTimes(1);
  });

  it("stores uploaded files through the storage helper", async () => {
    const caller = appRouter.createCaller({ user: null, req: {}, res: {} } as never);
    const result = await caller.dashboard.uploadFile({ token: "shared-token-123", fileName: "worksheet.pdf", mimeType: "application/pdf", base64: Buffer.from("worksheet").toString("base64") });
    expect(result.url).toContain("/manus-storage/");
    expect(result.name).toBe("worksheet.pdf");
  });

  it("reads and updates the same dashboard through its token", async () => {
    const caller = appRouter.createCaller({ user: null, req: {}, res: {} } as never);
    const token = "shared-token-123";
    const read = await caller.dashboard.byToken({ token });
    expect(read?.shareToken).toBe(token);
    const updated = await caller.dashboard.updateByToken({ token, update: { title: "Обновлённый кабинет", studentName: "Аня", data: validData } });
    expect(updated.title).toBe("Обновлённый кабинет");
    expect(updated.studentName).toBe("Аня");
    expect(updated.data).toEqual(validData);
  });
});
