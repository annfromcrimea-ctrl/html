import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter, dashboardDataSchema, isReminderDueSoon } from "../routers";
import { getDashboardByTaskUid, updateDashboard } from "../db";
import { createContext } from "./context";
import { sdk } from "./sdk";
import { notifyOwner } from "./notification";
import { serveStatic, setupVite } from "./vite";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);
  app.post("/api/scheduled/dashboardReminder", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      if (!user.isCron || !user.taskUid) return res.status(403).json({ error: "cron-only" });
      const dashboard = await getDashboardByTaskUid(user.taskUid);
      if (!dashboard) return res.json({ ok: true, skipped: "orphan" });
      const data = dashboardDataSchema.parse(JSON.parse(dashboard.data));
      const lesson = data.schedule.find(item => isReminderDueSoon(item.dateKey, item.date));
      const homework = data.homework.find(item => item.status === "pending" && isReminderDueSoon(item.dueDateKey, item.dueDate));
      const parts = [lesson ? `Ближайшее занятие: ${lesson.title}, ${lesson.date} в ${lesson.time}.` : "", homework ? `Срок задания «${homework.title}» — ${homework.dueDate}.` : ""].filter(Boolean);
      const reminderNotice = parts.join(" ") || "На сегодня новых напоминаний нет.";
      await updateDashboard(dashboard.id, { data: JSON.stringify({ ...data, reminderNotice }) });
      const delivered = await notifyOwner({ title: `Studyroom: ${dashboard.studentName}`, content: reminderNotice });
      return res.json({ ok: true, reminderNotice, delivered });
    } catch (error) {
      return res.status(500).json({ error: error instanceof Error ? error.message : String(error), stack: error instanceof Error ? error.stack : undefined, context: { url: req.originalUrl }, timestamp: new Date().toISOString() });
    }
  });
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
