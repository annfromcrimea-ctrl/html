import { describe, expect, it, vi } from "vitest";

const state = vi.hoisted(() => ({
  invite: null as any,
  student: null as any,
  dashboard: null as any,
  roles: new Map<number, string>(),
}));

vi.mock("./db", () => ({
  createTeacherInvite: vi.fn(async (input: any) => {
    state.invite = { id: 1, ...input, status: "pending" };
    return state.invite;
  }),
  getTeacherInviteByToken: vi.fn(async (token: string) => state.invite?.inviteToken === token ? state.invite : undefined),
  acceptTeacherInvite: vi.fn(async (id: number, userId: number) => {
    if (state.invite?.id === id) state.invite = { ...state.invite, status: "accepted", acceptedBy: userId };
  }),
  updateUserRole: vi.fn(async (userId: number, role: string) => state.roles.set(userId, role)),
  createDashboard: vi.fn(async (input: any) => {
    state.dashboard = { id: 7, ...input, createdAt: new Date(), updatedAt: new Date() };
    return state.dashboard;
  }),
  createTeacherStudent: vi.fn(async (input: any) => {
    state.student = { id: 9, ...input, status: "pending" };
    return state.student;
  }),
  updateTeacherStudent: vi.fn(async (id: number, update: any) => {
    if (state.student?.id === id) state.student = { ...state.student, ...update };
  }),
  getTeacherStudentByInviteToken: vi.fn(async (token: string) => state.student?.inviteToken === token ? state.student : undefined),
  getDashboardByToken: vi.fn(async (token: string) => state.dashboard?.shareToken === token ? state.dashboard : undefined),
  canUserAccessDashboard: vi.fn(async (userId: number, role: string, dashboard: any) => {
    if (role === "owner" || role === "admin" || dashboard.ownerId === userId) return true;
    return role === "teacher" && state.student?.dashboardId === dashboard.id && state.student.assignedTeacherId === userId;
  }),
}));

import { appRouter } from "./routers";

const context = (id: number, role: string, name = "Пользователь") => ({
  user: { id, openId: `user-${id}`, role, name, email: `${id}@example.com`, loginMethod: "manus", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
  req: { headers: {} },
  res: {},
}) as never;

const data = { profiles: [], activeProfileId: "", reminderNotice: "", topics: [], homework: [], schedule: [], notes: [], progress: { overall: 0, streak: 0, completedLessons: 0, weeklyGoal: 0 } };

describe("teacher invite and assignment workflow", () => {
  it("invites, accepts, assigns, then restricts dashboard access", async () => {
    const owner = appRouter.createCaller(context(1, "owner", "Владелец"));
    const teacher = appRouter.createCaller(context(2, "user", "Преподаватель"));
    const otherTeacher = appRouter.createCaller(context(3, "teacher", "Другой преподаватель"));

    const invite = await owner.teacher.inviteTeacher({ name: "Преподаватель", email: "2@example.com", role: "teacher" });
    await teacher.teacher.acceptTeacherInvite({ inviteToken: invite.inviteToken });
    expect(state.roles.get(2)).toBe("teacher");
    expect(state.invite.status).toBe("accepted");

    const student = await owner.teacher.addStudent({ name: "Аня", email: "anya@example.com" });
    await owner.teacher.assignStudent({ studentId: student.id, assignedTeacherId: 2 });
    expect(state.student.assignedTeacherId).toBe(2);

    const allowed = await teacher.dashboard.byToken({ token: student.shareToken });
    expect(allowed?.shareToken).toBe(student.shareToken);
    await expect(otherTeacher.dashboard.byToken({ token: student.shareToken })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
