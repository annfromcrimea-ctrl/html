import { nanoid } from "nanoid";
import { parse as parseCookie } from "cookie";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { createHeartbeatJob } from "./_core/heartbeat";
import { storagePut } from "./storage";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { canUserAccessDashboard, createDashboard, createTeacherInvite, createTeacherStudent, acceptTeacherInvite, getDashboardById, getDashboardByOwner, getDashboardByToken, getTeacherInviteByToken, getTeacherStudentByInviteToken, listAllTeacherStudents, listAssignedTeacherStudents, listTeacherInvites, listTeacherStudents, updateDashboard, updateTeacherStudent, updateUserRole } from "./db";

export const isReminderDueSoon = (dateKey: string, fallbackLabel?: string) => { if (fallbackLabel === "Сегодня" || fallbackLabel === "Завтра") return true; if (!/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) return false; const due = new Date(`${dateKey}T23:59:59.999Z`).getTime(); const now = Date.now(); return due >= now - 24 * 60 * 60 * 1000 && due <= now + 48 * 60 * 60 * 1000; };

export const dashboardDataSchema = z.object({
  profiles: z.array(z.object({ id: z.string(), name: z.string(), role: z.enum(["student", "teacher", "parent"]), email: z.string() })).default([]),
  activeProfileId: z.string().default(""),
  reminderNotice: z.string().default(""),
  topics: z.array(z.object({ id: z.string(), title: z.string(), description: z.string(), status: z.enum(["active", "done"]), color: z.string(), attachments: z.array(z.object({ id: z.string(), name: z.string(), url: z.string(), mimeType: z.string(), size: z.number() })).default([]) })),
  homework: z.array(z.object({ id: z.string(), title: z.string(), subject: z.string(), dueDate: z.string(), dueDateKey: z.string().default(""), status: z.enum(["pending", "done"]), priority: z.enum(["normal", "high"]), attachments: z.array(z.object({ id: z.string(), name: z.string(), url: z.string(), mimeType: z.string(), size: z.number() })).default([]), comments: z.array(z.object({ id: z.string(), author: z.string(), role: z.enum(["student", "teacher", "parent"]), text: z.string().min(1).max(2000), createdAt: z.string() })).default([]) })),
  schedule: z.array(z.object({ id: z.string(), date: z.string(), time: z.string(), title: z.string(), type: z.enum(["lesson", "review", "exam"]), duration: z.string(), reminderMinutes: z.number().default(30), dateKey: z.string().default("") })),
  notes: z.array(z.object({ id: z.string(), title: z.string(), content: z.string(), date: z.string(), tone: z.enum(["cream", "blue", "green"]) })),
  progress: z.object({ overall: z.number(), streak: z.number(), completedLessons: z.number(), weeklyGoal: z.number() }),
});

export type DashboardData = z.infer<typeof dashboardDataSchema>;
export const setActiveProfile = (data: DashboardData, profileId: string): DashboardData => data.profiles.some(profile => profile.id === profileId) ? { ...data, activeProfileId: profileId } : data;
export const removeDashboardAttachment = (data: DashboardData, kind: "topics" | "homework", recordId: string, attachmentId: string): DashboardData => ({ ...data, [kind]: data[kind].map(record => record.id === recordId ? { ...record, attachments: record.attachments.filter(file => file.id !== attachmentId) } : record) } as DashboardData);
export const appendHomeworkComment = (data: DashboardData, homeworkId: string, comment: DashboardData["homework"][number]["comments"][number]): DashboardData => ({ ...data, homework: data.homework.map(item => item.id === homeworkId ? { ...item, comments: [...item.comments, comment] } : item) });
export const scheduleOnDate = (data: DashboardData, dateKey: string) => data.schedule.filter(item => item.dateKey === dateKey);
export const canManageSchoolTeam = (role: string) => role === "admin" || role === "owner";
export const teacherInviteInputSchema = z.object({ name: z.string().min(1).max(120), email: z.string().email(), role: z.enum(["teacher", "admin"]).default("teacher") });

export const updateSchema = z.object({
  title: z.string().min(1).max(160),
  studentName: z.string().min(1).max(120),
  data: dashboardDataSchema,
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  teacher: router({
    team: protectedProcedure.query(async ({ ctx }) => {
      if (!canManageSchoolTeam(ctx.user.role)) throw new TRPCError({ code: "FORBIDDEN", message: "Управлять командой может только владелец школы или администратор" });
      return listTeacherInvites(ctx.user.id);
    }),
    inviteTeacher: protectedProcedure.input(teacherInviteInputSchema).mutation(async ({ ctx, input }) => {
      if (!canManageSchoolTeam(ctx.user.role)) throw new TRPCError({ code: "FORBIDDEN", message: "Приглашать преподавателей может только владелец школы или администратор" });
      return createTeacherInvite({ ownerId: ctx.user.id, name: input.name, email: input.email, role: input.role, inviteToken: nanoid(24) });
    }),
    acceptTeacherInvite: protectedProcedure.input(z.object({ inviteToken: z.string().min(8).max(48) })).mutation(async ({ ctx, input }) => {
      const invite = await getTeacherInviteByToken(input.inviteToken);
      if (!invite) throw new TRPCError({ code: "NOT_FOUND", message: "Приглашение преподавателя не найдено" });
      await acceptTeacherInvite(invite.id, ctx.user.id);
      if (ctx.user.role === "user") await updateUserRole(ctx.user.id, invite.role === "admin" ? "admin" : "teacher");
      return { success: true, role: invite.role, ownerId: invite.ownerId } as const;
    }),
    assignStudent: protectedProcedure.input(z.object({ studentId: z.number().int().positive(), assignedTeacherId: z.number().int().positive().nullable() })).mutation(async ({ ctx, input }) => {
      if (!canManageSchoolTeam(ctx.user.role)) throw new TRPCError({ code: "FORBIDDEN", message: "Распределять учеников может только владелец школы или администратор" });
      await updateTeacherStudent(input.studentId, { assignedTeacherId: input.assignedTeacherId });
      return { success: true } as const;
    }),
    students: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin" && ctx.user.role !== "owner" && ctx.user.role !== "teacher") throw new TRPCError({ code: "FORBIDDEN", message: "Доступ только для преподавателей" });
      const rows = ctx.user.role === "admin" || ctx.user.role === "owner" ? await listAllTeacherStudents() : await listAssignedTeacherStudents(ctx.user.id);
      return Promise.all(rows.map(async row => { const dashboard = row.dashboardId ? await getDashboardById(row.dashboardId) : undefined; const data = dashboard ? dashboardDataSchema.parse(JSON.parse(dashboard.data)) : null; return { ...row, shareToken: dashboard?.shareToken ?? null, progress: data?.progress.overall ?? 0, pendingHomework: data?.homework.filter(item => item.status === "pending").length ?? 0 }; }));
    }),
    addStudent: protectedProcedure.input(z.object({ name: z.string().min(1).max(120), email: z.string().email().optional() })).mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "admin" && ctx.user.role !== "owner" && ctx.user.role !== "teacher") throw new TRPCError({ code: "FORBIDDEN", message: "Доступ только для преподавателей" });
      const shareToken = nanoid(18);
      const dashboard = await createDashboard({ ownerId: ctx.user.id, shareToken, title: `Кабинет ${input.name}`, studentName: input.name, data: JSON.stringify({ profiles: [{ id: "student", name: input.name, role: "student", email: input.email ?? "" }, { id: "teacher", name: ctx.user.name ?? "Преподаватель", role: "teacher", email: ctx.user.email ?? "" }], activeProfileId: "student", reminderNotice: "", topics: [], homework: [], schedule: [], notes: [], progress: { overall: 0, streak: 0, completedLessons: 0, weeklyGoal: 0 } }) });
      const student = await createTeacherStudent({ teacherId: ctx.user.id, assignedTeacherId: ctx.user.role === "teacher" ? ctx.user.id : null, dashboardId: dashboard?.id ?? null, name: input.name, email: input.email ?? null, inviteToken: nanoid(24) });
      return { ...student, shareToken: dashboard?.shareToken ?? shareToken };
    }),
    acceptInvite: protectedProcedure.input(z.object({ inviteToken: z.string().min(8).max(48) })).mutation(async ({ ctx, input }) => {
      const student = await getTeacherStudentByInviteToken(input.inviteToken);
      if (!student) throw new TRPCError({ code: "NOT_FOUND", message: "Приглашение не найдено" });
      const dashboard = student.dashboardId ? await getDashboardById(student.dashboardId) : undefined;
      await updateTeacherStudent(student.id, { status: "active", email: ctx.user.email ?? student.email });
      return { success: true, shareToken: dashboard?.shareToken ?? null };
    }),
  }),
  dashboard: router({
    mine: protectedProcedure.query(async ({ ctx }) => getDashboardByOwner(ctx.user.id)),
    create: protectedProcedure.input(z.object({ title: z.string(), studentName: z.string(), data: dashboardDataSchema })).mutation(async ({ ctx, input }) =>
      createDashboard({ ownerId: ctx.user.id, shareToken: nanoid(18), title: input.title, studentName: input.studentName, data: JSON.stringify(input.data) })
    ),
    byToken: publicProcedure.input(z.object({ token: z.string().min(8).max(48) })).query(async ({ ctx, input }) => {
      const dashboard = await getDashboardByToken(input.token);
      if (!dashboard) return null;
      if (ctx.user && (ctx.user.role === "teacher" || ctx.user.role === "admin" || ctx.user.role === "owner") && !(await canUserAccessDashboard(ctx.user.id, ctx.user.role, dashboard))) throw new TRPCError({ code: "FORBIDDEN", message: "Этот кабинет не назначен вам" });
      return { ...dashboard, data: dashboardDataSchema.parse(JSON.parse(dashboard.data)) };
    }),
    updateByToken: publicProcedure.input(z.object({ token: z.string().min(8).max(48), update: updateSchema })).mutation(async ({ ctx, input }) => {
      const dashboard = await getDashboardByToken(input.token);
      if (!dashboard) throw new Error("Dashboard not found");
      if (ctx.user && (ctx.user.role === "teacher" || ctx.user.role === "admin" || ctx.user.role === "owner") && !(await canUserAccessDashboard(ctx.user.id, ctx.user.role, dashboard))) throw new TRPCError({ code: "FORBIDDEN", message: "Редактирование этого кабинета вам не назначено" });
      await updateDashboard(dashboard.id, { title: input.update.title, studentName: input.update.studentName, data: JSON.stringify(input.update.data) });
      return { ...dashboard, title: input.update.title, studentName: input.update.studentName, data: input.update.data };
    }),
    enableReminders: protectedProcedure.input(z.object({ token: z.string().min(8).max(48) })).mutation(async ({ ctx, input }) => {
      const dashboard = await getDashboardByToken(input.token);
      if (!dashboard || dashboard.ownerId !== ctx.user.id) throw new Error("Dashboard not found");
      if (dashboard.scheduleCronTaskUid) return { enabled: true, taskUid: dashboard.scheduleCronTaskUid };
      const sessionToken = parseCookie(ctx.req.headers.cookie ?? "")[COOKIE_NAME] ?? "";
      const job = await createHeartbeatJob({ name: `dashboard-reminders-${dashboard.id}`, cron: "0 0 * * * *", path: "/api/scheduled/dashboardReminder", description: `Напоминания для кабинета ${dashboard.id}` }, sessionToken);
      await updateDashboard(dashboard.id, { scheduleCronTaskUid: job.taskUid });
      return { enabled: true, taskUid: job.taskUid, nextExecutionAt: job.nextExecutionAt ?? null };
    }),
    uploadFile: publicProcedure.input(z.object({ token: z.string().min(8).max(48), fileName: z.string().min(1).max(180), mimeType: z.string().max(120), base64: z.string().max(8_000_000) })).mutation(async ({ ctx, input }) => {
      const dashboard = await getDashboardByToken(input.token);
      if (!dashboard) throw new Error("Dashboard not found");
      if (ctx.user && (ctx.user.role === "teacher" || ctx.user.role === "admin" || ctx.user.role === "owner") && !(await canUserAccessDashboard(ctx.user.id, ctx.user.role, dashboard))) throw new TRPCError({ code: "FORBIDDEN", message: "Загрузка в этот кабинет вам не назначена" });
      const bytes = Buffer.from(input.base64, "base64");
      if (bytes.length > 6 * 1024 * 1024) throw new Error("File is larger than 6 MB");
      const stored = await storagePut(`dashboards/${dashboard.id}/${nanoid(10)}-${input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-")}`, bytes, input.mimeType || "application/octet-stream");
      return { id: nanoid(12), name: input.fileName, url: stored.url, mimeType: input.mimeType || "application/octet-stream", size: bytes.length };
    }),
  }),
});

export type AppRouter = typeof appRouter;
