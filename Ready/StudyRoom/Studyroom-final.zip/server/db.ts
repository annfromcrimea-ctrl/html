import { and, eq, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, StudentDashboard, studentDashboards, teacherInvites, teacherStudents, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  textFields.forEach(field => {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  });
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "owner";
    updateSet.role = "owner";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function updateUserRole(userId: number, role: "user" | "teacher" | "admin" | "owner") {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(users).set({ role }).where(eq(users.id, userId));
}

export async function getDashboardByOwner(ownerId: number): Promise<StudentDashboard | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(studentDashboards).where(eq(studentDashboards.ownerId, ownerId)).limit(1);
  return result[0];
}

export async function getDashboardById(id: number): Promise<StudentDashboard | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(studentDashboards).where(eq(studentDashboards.id, id)).limit(1);
  return result[0];
}

export async function getDashboardByToken(shareToken: string): Promise<StudentDashboard | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(studentDashboards).where(eq(studentDashboards.shareToken, shareToken)).limit(1);
  return result[0];
}

export function canAccessDashboardByRole(userId: number, role: string, ownerId: number, assignedTeacherId: number | null) {
  if (role === "admin" || role === "owner" || ownerId === userId) return true;
  return role === "teacher" && assignedTeacherId === userId;
}

export async function canUserAccessDashboard(userId: number, role: string, dashboard: StudentDashboard) {
  if (canAccessDashboardByRole(userId, role, dashboard.ownerId, null)) return true;
  if (role !== "teacher") return false;
  const db = await getDb();
  if (!db) return false;
  const result = await db.select({ id: teacherStudents.id }).from(teacherStudents).where(and(eq(teacherStudents.dashboardId, dashboard.id), eq(teacherStudents.assignedTeacherId, userId))).limit(1);
  return result.length > 0;
}

export async function getDashboardByTaskUid(taskUid: string): Promise<StudentDashboard | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(studentDashboards).where(eq(studentDashboards.scheduleCronTaskUid, taskUid)).limit(1);
  return result[0];
}

export async function createDashboard(input: {
  ownerId: number;
  shareToken: string;
  title: string;
  studentName: string;
  data: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(studentDashboards).values(input);
  return getDashboardByToken(input.shareToken);
}

export async function updateDashboard(id: number, input: { title?: string; studentName?: string; data?: string; scheduleCronTaskUid?: string | null }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(studentDashboards).set(input).where(eq(studentDashboards.id, id));
}

export async function listTeacherStudents(teacherId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(teacherStudents).where(eq(teacherStudents.teacherId, teacherId));
}

export async function listAssignedTeacherStudents(assignedTeacherId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(teacherStudents).where(eq(teacherStudents.assignedTeacherId, assignedTeacherId));
}

export async function listAllTeacherStudents() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(teacherStudents);
}

export async function getTeacherStudentByInviteToken(inviteToken: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(teacherStudents).where(eq(teacherStudents.inviteToken, inviteToken)).limit(1);
  return result[0];
}

export async function updateTeacherStudent(id: number, input: { status?: string; email?: string | null; assignedTeacherId?: number | null }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(teacherStudents).set(input).where(eq(teacherStudents.id, id));
}

export async function listTeacherInvites(ownerId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(teacherInvites).where(eq(teacherInvites.ownerId, ownerId));
}

export async function createTeacherInvite(input: { ownerId: number; name: string; email: string; role: string; inviteToken: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(teacherInvites).values(input);
  const result = await db.select().from(teacherInvites).where(eq(teacherInvites.inviteToken, input.inviteToken)).limit(1);
  return result[0];
}

export async function getTeacherInviteByToken(inviteToken: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(teacherInvites).where(eq(teacherInvites.inviteToken, inviteToken)).limit(1);
  return result[0];
}

export async function acceptTeacherInvite(id: number, teacherUserId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(teacherInvites).set({ teacherUserId, status: "accepted" }).where(eq(teacherInvites.id, id));
}

export async function createTeacherStudent(input: { teacherId: number; assignedTeacherId?: number | null; dashboardId?: number | null; name: string; email?: string | null; inviteToken: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(teacherStudents).values(input);
  const result = await db.select().from(teacherStudents).where(eq(teacherStudents.inviteToken, input.inviteToken)).limit(1);
  return result[0];
}
