# Shared Link Check

The direct route `/share/shared-token-123` loads the shared-dashboard shell and resolves to the expected not-found state because that token is not present in the database. The page shows the user-facing message “Кабинет не найден” and instructs the viewer to request a fresh link, confirming that invalid shared URLs do not crash the application. A valid generated token is required to complete authenticated data-flow testing after dashboard creation.
