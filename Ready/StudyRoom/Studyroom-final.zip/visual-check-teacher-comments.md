# Teacher Portal and Homework Comments Check

The teacher route renders a dedicated “Мои ученики” workspace with overview metrics, search, an add-student action, and an empty state when no student records exist. The homework section renders a clear “Вопросы и комментарии” thread inside each assignment, with a text field and send action, while preserving attachment and edit controls. Both views use the existing responsive visual system.
