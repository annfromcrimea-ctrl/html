import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Teacher from "./pages/Teacher";
import Invite from "./pages/Invite";

function Router() {
  return <Switch>
    <Route path="/" component={Home} />
    <Route path="/share/:token" component={Home} />
    <Route path="/teacher" component={Teacher} />
    <Route path="/teacher/invite/:token" component={Invite} />
    <Route path="/invite/:token" component={Invite} />
    <Route path="/404" component={NotFound} />
    <Route component={NotFound} />
  </Switch>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><Toaster /><Router /></TooltipProvider></ThemeProvider></ErrorBoundary>;
}
