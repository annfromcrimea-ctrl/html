import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { CheckCircle2, GraduationCap, Users } from "lucide-react";
import { useEffect } from "react";
import { useLocation, useRoute } from "wouter";

export default function Invite() {
  const [, studentParams] = useRoute("/invite/:token");
  const [, teacherParams] = useRoute("/teacher/invite/:token");
  const [, setLocation] = useLocation();
  const { user, loading } = useAuth();
  const isTeacherInvite = Boolean(teacherParams?.token);
  const token = (teacherParams?.token ?? studentParams?.token) ?? "";
  const acceptStudent = trpc.teacher.acceptInvite.useMutation({ onSuccess: result => setLocation(result.shareToken ? `/share/${result.shareToken}` : "/") });
  const acceptTeacher = trpc.teacher.acceptTeacherInvite.useMutation({ onSuccess: () => setLocation("/teacher") });
  const activeAccept = isTeacherInvite ? acceptTeacher : acceptStudent;

  useEffect(() => {
    if (user && token && !activeAccept.isPending && !activeAccept.isSuccess) {
      if (isTeacherInvite) acceptTeacher.mutate({ inviteToken: token });
      else acceptStudent.mutate({ inviteToken: token });
    }
  }, [user, token, isTeacherInvite]);

  if (loading || activeAccept.isPending) return <div className="min-h-screen grid place-items-center bg-[#f8f7f4]"><div className="h-8 w-8 animate-spin rounded-full border-2 border-[#6c5ce7] border-t-transparent" /></div>;
  if (!user) return <div className="min-h-screen grid place-items-center bg-[#f8f7f4] p-6"><Card className="max-w-md border-0 shadow-xl"><CardContent className="p-8 text-center"><div className="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-[#eeebff] text-[#6c5ce7]">{isTeacherInvite ? <Users className="h-6 w-6" /> : <GraduationCap className="h-6 w-6" />}</div><h1 className="text-2xl font-semibold">{isTeacherInvite ? "Приглашение в команду" : "Приглашение в Studyroom"}</h1><p className="mt-2 text-muted-foreground">{isTeacherInvite ? "Войдите, чтобы присоединиться к команде онлайн-школы." : "Войдите, чтобы присоединиться к кабинету ученика."}</p><Button onClick={() => startLogin()} className="mt-6 rounded-xl bg-[#24222d]">Войти и принять</Button></CardContent></Card></div>;
  if (activeAccept.error) return <div className="min-h-screen grid place-items-center bg-[#f8f7f4] p-6"><Card className="max-w-md border-0 shadow-xl"><CardContent className="p-8 text-center"><h1 className="text-2xl font-semibold">Приглашение недоступно</h1><p className="mt-2 text-muted-foreground">Попросите администратора школы создать новую ссылку.</p></CardContent></Card></div>;
  return <div className="min-h-screen grid place-items-center bg-[#f8f7f4] p-6"><Card className="max-w-md border-0 shadow-xl"><CardContent className="p-8 text-center"><CheckCircle2 className="mx-auto mb-4 h-10 w-10 text-[#268765]" /><h1 className="text-2xl font-semibold">Готово</h1><p className="mt-2 text-muted-foreground">{isTeacherInvite ? "Открываем рабочее пространство преподавателя." : "Открываем ваш учебный кабинет."}</p></CardContent></Card></div>;
}
