import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, CheckCircle2, ClipboardList, Link2, Plus, Search, Users, X } from "lucide-react";
import { useMemo, useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { createScheduleEvent, displayDateFor, updateScheduleEvent } from "@shared/schedule";

export default function Teacher() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();
  const canManage = user?.role === "teacher" || user?.role === "admin" || user?.role === "owner";
  const students = trpc.teacher.students.useQuery(undefined, { enabled: !!user && canManage });
  const team = trpc.teacher.team.useQuery(undefined, { enabled: user?.role === "admin" || user?.role === "owner" });
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [search, setSearch] = useState("");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [quickTask, setQuickTask] = useState("");
  const [quickComment, setQuickComment] = useState("");
  const [quickSchedule, setQuickSchedule] = useState("");
  const [selectedHomeworkId, setSelectedHomeworkId] = useState<string>("");
  const [selectedScheduleId, setSelectedScheduleId] = useState<string>("");
  const [quickDate, setQuickDate] = useState("");
  const [quickDuration, setQuickDuration] = useState("");
  const [quickReminder, setQuickReminder] = useState("30");
  const addStudent = trpc.teacher.addStudent.useMutation({
    onSuccess: () => { students.refetch(); setOpen(false); setName(""); setEmail(""); toast.success("Кабинет ученика создан"); },
  });
  const assignStudent = trpc.teacher.assignStudent.useMutation({ onSuccess: () => { students.refetch(); toast.success("Ответственный преподаватель обновлён"); } });
  const inviteTeacher = trpc.teacher.inviteTeacher.useMutation({ onSuccess: () => { team.refetch(); setTeamOpen(false); setTeamName(""); setTeamEmail(""); toast.success("Приглашение преподавателя создано"); } });
  const [teamOpen, setTeamOpen] = useState(false);
  const [teamName, setTeamName] = useState("");
  const [teamEmail, setTeamEmail] = useState("");
  const [teamRole, setTeamRole] = useState<"teacher" | "admin">("teacher");
  const filtered = useMemo(() => (students.data ?? []).filter(student => `${student.name} ${student.email ?? ""}`.toLowerCase().includes(search.toLowerCase())), [students.data, search]);
  const selected = (students.data ?? []).find(student => student.id === selectedId);
  const selectedDashboard = trpc.dashboard.byToken.useQuery({ token: selected?.shareToken ?? "" }, { enabled: !!selected?.shareToken });
  const uploadFile = trpc.dashboard.uploadFile.useMutation();
  const updateSelected = trpc.dashboard.updateByToken.useMutation({ onSuccess: () => { selectedDashboard.refetch(); setQuickTask(""); setQuickComment(""); setQuickSchedule(""); toast.success("Изменения сохранены"); } });
  const selectedHomework = selectedDashboard.data?.data.homework.find(item => item.id === selectedHomeworkId) ?? selectedDashboard.data?.data.homework[0];
  const selectedSchedule = selectedDashboard.data?.data.schedule.find(item => item.id === selectedScheduleId) ?? selectedDashboard.data?.data.schedule[0];
  const saveSelected = (nextData: NonNullable<typeof selectedDashboard.data>["data"]) => { if (!selected?.shareToken || !selectedDashboard.data) return; updateSelected.mutate({ token: selected.shareToken, update: { title: selectedDashboard.data.title, studentName: selectedDashboard.data.studentName, data: nextData } }); };
  const assignHomework = () => { if (!selectedDashboard.data || !quickTask.trim()) return; const nextData = { ...selectedDashboard.data.data, homework: [{ id: `${Date.now()}`, title: quickTask.trim(), subject: "Новое задание", dueDate: "Без срока", dueDateKey: "", status: "pending" as const, priority: "normal" as const, attachments: [], comments: [] }, ...selectedDashboard.data.data.homework] }; saveSelected(nextData); };
  const addTeacherComment = () => { if (!selectedDashboard.data || !quickComment.trim() || !selectedHomework) return; const item = selectedHomework; const nextData = { ...selectedDashboard.data.data, homework: selectedDashboard.data.data.homework.map(homework => homework.id === item.id ? { ...homework, comments: [...homework.comments, { id: `${Date.now()}`, author: user?.name ?? "Преподаватель", role: "teacher" as const, text: quickComment.trim(), createdAt: new Date().toISOString() }] } : homework) }; saveSelected(nextData); };
  const addSchedule = () => { if (!selectedDashboard.data || !quickSchedule.trim()) return; const dateKey = quickDate || new Date().toISOString().slice(0, 10); const nextEvent = createScheduleEvent({ id: `${Date.now()}`, title: quickSchedule.trim(), dateKey, time: "16:00", duration: quickDuration || "60 мин", reminderMinutes: Number(quickReminder) || 30 }); saveSelected({ ...selectedDashboard.data.data, schedule: [nextEvent, ...selectedDashboard.data.data.schedule] }); };
  const editSelectedHomework = (field: "title" | "subject", value: string) => { if (!selectedDashboard.data || !selectedHomework) return; saveSelected({ ...selectedDashboard.data.data, homework: selectedDashboard.data.data.homework.map(item => item.id === selectedHomework.id ? { ...item, [field]: value } : item) }); };
  const editSelectedComment = (commentId: string, text: string) => { if (!selectedDashboard.data || !selectedHomework) return; saveSelected({ ...selectedDashboard.data.data, homework: selectedDashboard.data.data.homework.map(item => item.id === selectedHomework.id ? { ...item, comments: item.comments.map(comment => comment.id === commentId ? { ...comment, text } : comment) } : item) }); };
  const removeSelectedComment = (commentId: string) => { if (!selectedDashboard.data || !selectedHomework) return; saveSelected({ ...selectedDashboard.data.data, homework: selectedDashboard.data.data.homework.map(item => item.id === selectedHomework.id ? { ...item, comments: item.comments.filter(comment => comment.id !== commentId) } : item) }); };
  const editSelectedSchedule = (field: "title" | "time" | "dateKey" | "duration" | "reminderMinutes", value: string | number) => { if (!selectedDashboard.data || !selectedSchedule) return; const nextItem = updateScheduleEvent(selectedSchedule, { [field]: field === "reminderMinutes" ? Number(value) : value }); saveSelected({ ...selectedDashboard.data.data, schedule: selectedDashboard.data.data.schedule.map(item => item.id === selectedSchedule.id ? nextItem : item) }); };
  const removeSelectedFile = (attachmentId: string) => { if (!selectedDashboard.data || !selectedHomework) return; saveSelected({ ...selectedDashboard.data.data, homework: selectedDashboard.data.data.homework.map(item => item.id === selectedHomework.id ? { ...item, attachments: item.attachments.filter(file => file.id !== attachmentId) } : item) }); };
  const uploadToSelected = async (file: File) => { if (!selected?.shareToken || !selectedDashboard.data || !selectedHomework) return; const base64 = await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result).split(",")[1] ?? ""); reader.onerror = reject; reader.readAsDataURL(file); }); const uploaded = await uploadFile.mutateAsync({ token: selected.shareToken, fileName: file.name, mimeType: file.type, base64 }); saveSelected({ ...selectedDashboard.data.data, homework: selectedDashboard.data.data.homework.map(homework => homework.id === selectedHomework.id ? { ...homework, attachments: [...homework.attachments, uploaded] } : homework) }); };

  if (loading || (canManage && students.isLoading)) return <div className="min-h-screen grid place-items-center bg-[#f8f7f4]"><div className="h-8 w-8 animate-spin rounded-full border-2 border-[#6c5ce7] border-t-transparent" /></div>;
  if (!user) return <div className="min-h-screen grid place-items-center bg-[#f8f7f4] p-6"><Card className="max-w-md border-0 shadow-xl"><CardContent className="p-8 text-center"><Users className="mx-auto mb-4 h-10 w-10 text-[#6c5ce7]" /><h1 className="text-2xl font-semibold">Сайт преподавателя</h1><p className="mt-2 text-muted-foreground">Войдите, чтобы управлять кабинетами учеников.</p><Button onClick={() => startLogin()} className="mt-6 rounded-xl bg-[#24222d]">Войти</Button></CardContent></Card></div>;

  if (!canManage) return <div className="min-h-screen grid place-items-center bg-[#f8f7f4] p-6"><Card className="max-w-md border-0 shadow-xl"><CardContent className="p-8 text-center"><Users className="mx-auto mb-4 h-10 w-10 text-[#6c5ce7]" /><h1 className="text-2xl font-semibold">Нет доступа</h1><p className="mt-2 text-muted-foreground">Этот раздел доступен только преподавателю или администратору.</p><Button onClick={() => setLocation("/")} className="mt-6 rounded-xl bg-[#24222d]">Вернуться в кабинет</Button></CardContent></Card></div>;

  return (
    <div className="min-h-screen bg-[#f8f7f4] text-[#22212a]">
      <main className="mx-auto max-w-[1200px] px-5 py-8 sm:px-8 lg:px-12">
        <header className="flex flex-col justify-between gap-5 sm:flex-row sm:items-center">
          <div>
            <Button variant="ghost" onClick={() => setLocation("/")} className="mb-4 -ml-3 rounded-xl text-muted-foreground"><ArrowLeft className="mr-2 h-4 w-4" />В кабинет</Button>
            <p className="text-xs uppercase tracking-[0.15em] text-muted-foreground">Пространство преподавателя</p>
            <h1 className="mt-2 text-4xl font-semibold tracking-tight">Мои ученики</h1>
            <p className="mt-2 text-muted-foreground">Все кабинеты, задания и прогресс — в одном месте.</p>
          </div>
          <Button onClick={() => setOpen(true)} className="rounded-xl bg-[#6c5ce7] hover:bg-[#5c4dd2]"><Plus className="mr-2 h-4 w-4" />Добавить ученика</Button>
        </header>

        <div className="mt-10 grid gap-4 md:grid-cols-3">
          <Metric label="Всего учеников" value={students.data?.length ?? 0} />
          <Metric label="Активные кабинеты" value={students.data?.filter(item => item.status === "active").length ?? 0} />
          <Card className="border-0 bg-[#24222d] text-white shadow-sm"><CardContent className="p-5"><p className="text-sm text-white/60">Фокус</p><p className="mt-2 text-lg font-semibold">Поддерживать регулярный ритм</p></CardContent></Card>
        </div>

        {(user.role === "admin" || user.role === "owner") && <Card className="mt-8 border-0 bg-white shadow-sm"><CardContent className="p-5 sm:p-6"><div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center"><div><p className="text-xs uppercase tracking-[0.14em] text-[#6c5ce7]">Команда онлайн-школы</p><h2 className="mt-1 text-xl font-semibold">Преподаватели и аутсорсинг</h2><p className="mt-1 text-sm text-muted-foreground">Приглашайте сотрудников и распределяйте между ними учеников.</p></div><Button onClick={() => setTeamOpen(true)} className="rounded-xl bg-[#24222d]"><Plus className="mr-2 h-4 w-4" />Добавить преподавателя</Button></div><div className="mt-5 grid gap-3 sm:grid-cols-2">{(team.data ?? []).map(member => <div key={member.id} className="rounded-2xl border border-black/5 bg-[#f8f7f4] p-4"><div className="flex items-start justify-between gap-3"><div><p className="font-medium">{member.name}</p><p className="mt-1 text-sm text-muted-foreground">{member.email}</p></div><Badge className={member.status === "accepted" ? "border-0 bg-[#e6f5ef] text-[#268765]" : "border-0 bg-[#fff4d8] text-[#9b7411]"}>{member.status === "accepted" ? "Подключён" : "Ожидает"}</Badge></div><p className="mt-3 text-xs text-muted-foreground">Роль: {member.role === "admin" ? "Администратор" : "Преподаватель"}</p><p className="mt-2 break-all text-xs text-[#6c5ce7]">{window.location.origin}/teacher/invite/{member.inviteToken}</p></div>)}{team.data?.length === 0 && <p className="text-sm text-muted-foreground">Команда пока пустая. Создайте первое приглашение.</p>}</div></CardContent></Card>}

        <div className="mt-10 flex items-center gap-3 rounded-2xl bg-white px-4 py-3 shadow-sm"><Search className="h-5 w-5 text-muted-foreground" /><Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Найти ученика…" className="border-0 bg-transparent shadow-none focus-visible:ring-0" /></div>

        <section className="mt-6 grid gap-4 md:grid-cols-2">
          {filtered.map(student => <StudentCard key={student.id} student={student} selected={selectedId === student.id} onSelect={() => setSelectedId(student.id)} onOpen={() => setLocation(`/share/${student.shareToken}`)} />)}
          {filtered.length === 0 && <Card className="border-0 shadow-sm md:col-span-2"><CardContent className="p-10 text-center"><ClipboardList className="mx-auto h-9 w-9 text-muted-foreground" /><p className="mt-3 font-medium">Пока нет учеников</p><p className="mt-1 text-sm text-muted-foreground">Создайте первый кабинет и отправьте ученику его ссылку.</p></CardContent></Card>}
        </section>

        {selected && (
          <Card className="mt-6 border-0 bg-[#eeebff] shadow-sm">
            <CardContent className="p-6">
              <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
                <div><p className="text-xs uppercase tracking-[0.14em] text-[#6c5ce7]">Выбранный ученик</p><h2 className="mt-2 text-2xl font-semibold">{selected.name}</h2><p className="mt-1 text-sm text-muted-foreground">Быстрый просмотр и управление кабинетом без смены экрана.</p></div>
                <div className="flex flex-wrap gap-2"><select value={selected.assignedTeacherId ?? ""} onChange={e => assignStudent.mutate({ studentId: selected.id, assignedTeacherId: e.target.value ? Number(e.target.value) : null })} className="h-10 rounded-lg border border-black/10 bg-white px-3 text-sm"><option value="">Без назначения</option>{(team.data ?? []).filter(member => member.status === "accepted" && member.teacherUserId).map(member => <option key={member.id} value={member.teacherUserId ?? ""}>{member.name}</option>)}</select><Button onClick={() => setLocation(`/share/${selected.shareToken}`)} className="rounded-xl bg-[#24222d]">Открыть кабинет</Button></div>
              </div>
              {selectedDashboard.data && (
                <>
                  <div className="mt-5 grid gap-3 sm:grid-cols-3"><Mini label="Темы" value={selectedDashboard.data.data.topics.length} /><Mini label="Домашние задания" value={selectedDashboard.data.data.homework.length} /><Mini label="Комментарии" value={selectedDashboard.data.data.homework.reduce((sum, item) => sum + item.comments.length, 0)} /></div>
                  <div className="mt-5 grid gap-3 rounded-2xl bg-white/70 p-4">
                    <p className="text-sm font-semibold">Управление кабинетом без перехода</p>
                    <div className="grid gap-2 sm:grid-cols-[1fr_auto]"><select value={selectedHomework?.id ?? ""} onChange={e => setSelectedHomeworkId(e.target.value)} className="h-10 rounded-lg border border-black/10 bg-white px-3 text-sm"><option value="">Выбрать домашнее задание</option>{selectedDashboard.data.data.homework.map(item => <option key={item.id} value={item.id}>{item.title}</option>)}</select><label className="inline-flex cursor-pointer items-center justify-center rounded-lg border border-black/10 bg-white px-4 text-sm"><Link2 className="mr-2 h-4 w-4" />Файл<input type="file" className="hidden" onChange={e => { const file = e.target.files?.[0]; if (file) uploadToSelected(file); e.currentTarget.value = ""; }} /></label></div>
                    {selectedHomework && <><div className="grid gap-2 sm:grid-cols-2"><Input value={selectedHomework.title} onChange={e => editSelectedHomework("title", e.target.value)} className="bg-white" /><Input value={selectedHomework.subject} onChange={e => editSelectedHomework("subject", e.target.value)} className="bg-white" /></div><div className="flex flex-wrap gap-2">{selectedHomework.attachments.map(file => <span key={file.id} className="inline-flex items-center gap-1 rounded-md bg-white px-2 py-1 text-xs text-[#6c5ce7]">{file.name}<button onClick={() => removeSelectedFile(file.id)} className="text-[#d16b5f]">×</button></span>)}</div>{selectedHomework.comments.map(comment => <div key={comment.id} className="flex items-center gap-2"><Input value={comment.text} onChange={e => editSelectedComment(comment.id, e.target.value)} className="bg-white text-sm" /><Button variant="ghost" onClick={() => removeSelectedComment(comment.id)} className="text-[#d16b5f]">Удалить</Button></div>)}<div className="flex flex-col gap-2 sm:flex-row"><Textarea value={quickComment} onChange={e => setQuickComment(e.target.value)} placeholder="Добавить ответ или комментарий к выбранному заданию…" className="min-h-10 bg-white" /><Button onClick={addTeacherComment} disabled={!quickComment.trim() || updateSelected.isPending} variant="outline" className="rounded-xl border-[#dcd7fb] bg-white text-[#6c5ce7]">Ответить</Button></div></>}
                    <div className="grid gap-2 sm:grid-cols-[1fr_auto]"><select value={selectedSchedule?.id ?? ""} onChange={e => setSelectedScheduleId(e.target.value)} className="h-10 rounded-lg border border-black/10 bg-white px-3 text-sm"><option value="">Выбрать событие календаря</option>{selectedDashboard.data.data.schedule.map(item => <option key={item.id} value={item.id}>{item.title}</option>)}</select><Input value={quickSchedule} onChange={e => setQuickSchedule(e.target.value)} placeholder="Новое занятие…" className="bg-white" /></div><div className="grid gap-2 sm:grid-cols-2"><Input value={selectedSchedule?.title ?? ""} onChange={e => selectedSchedule ? editSelectedSchedule("title", e.target.value) : setQuickSchedule(e.target.value)} placeholder="Название выбранного события" className="bg-white" /><Input value={selectedSchedule?.date ?? ""} readOnly aria-label="Отображаемая дата, вычисляется из календарной даты" placeholder="Отображаемая дата" className="bg-[#f8f7f4]" /><Input type="date" value={selectedSchedule?.dateKey ?? quickDate} onChange={e => selectedSchedule ? editSelectedSchedule("dateKey", e.target.value) : setQuickDate(e.target.value)} className="bg-white" /><Input value={selectedSchedule?.time ?? "16:00"} onChange={e => selectedSchedule && editSelectedSchedule("time", e.target.value)} placeholder="Время" className="bg-white" /><Input value={selectedSchedule?.duration ?? quickDuration} onChange={e => selectedSchedule ? editSelectedSchedule("duration", e.target.value) : setQuickDuration(e.target.value)} placeholder="Длительность" className="bg-white" /><Input type="number" value={selectedSchedule?.reminderMinutes ?? quickReminder} onChange={e => selectedSchedule ? editSelectedSchedule("reminderMinutes", e.target.value) : setQuickReminder(e.target.value)} placeholder="Напоминание, мин" className="bg-white" /></div><div className="flex flex-col gap-2 sm:flex-row"><Input value={quickSchedule} onChange={e => setQuickSchedule(e.target.value)} placeholder="Новое занятие…" className="bg-white" /><Button onClick={addSchedule} disabled={!quickSchedule.trim() || updateSelected.isPending} variant="outline" className="rounded-xl border-black/10 bg-white">Добавить</Button></div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        )}
      </main>

      {teamOpen && <div className="fixed inset-0 z-50 grid place-items-center bg-black/30 p-5 backdrop-blur-sm"><Card className="w-full max-w-md border-0 shadow-2xl"><CardHeader className="flex-row items-center justify-between"><div><CardTitle>Пригласить преподавателя</CardTitle><p className="mt-1 text-sm text-muted-foreground">Сотрудник получит доступ после входа и принятия приглашения.</p></div><button onClick={() => setTeamOpen(false)} className="rounded-lg p-2 hover:bg-black/5"><X className="h-5 w-5" /></button></CardHeader><CardContent className="space-y-4"><Input autoFocus value={teamName} onChange={e => setTeamName(e.target.value)} placeholder="Имя преподавателя" /><Input value={teamEmail} onChange={e => setTeamEmail(e.target.value)} placeholder="Email преподавателя" type="email" /><select value={teamRole} onChange={e => setTeamRole(e.target.value as "teacher" | "admin")} className="h-10 w-full rounded-lg border border-black/10 bg-white px-3 text-sm"><option value="teacher">Преподаватель</option><option value="admin">Администратор</option></select><Button disabled={!teamName.trim() || !teamEmail.trim() || inviteTeacher.isPending} onClick={() => inviteTeacher.mutate({ name: teamName.trim(), email: teamEmail.trim(), role: teamRole })} className="w-full rounded-xl bg-[#6c5ce7]">Создать приглашение</Button></CardContent></Card></div>}

      {open && <div className="fixed inset-0 z-50 grid place-items-center bg-black/30 p-5 backdrop-blur-sm"><Card className="w-full max-w-md border-0 shadow-2xl"><CardHeader className="flex-row items-center justify-between"><div><CardTitle>Новый ученик</CardTitle><p className="mt-1 text-sm text-muted-foreground">Создайте отдельный кабинет для занятий.</p></div><button onClick={() => setOpen(false)} className="rounded-lg p-2 hover:bg-black/5"><X className="h-5 w-5" /></button></CardHeader><CardContent className="space-y-4"><Input autoFocus value={name} onChange={e => setName(e.target.value)} placeholder="Имя ученика" /><Input value={email} onChange={e => setEmail(e.target.value)} placeholder="Email (необязательно)" type="email" /><Button disabled={!name.trim() || addStudent.isPending} onClick={() => addStudent.mutate({ name: name.trim(), email: email.trim() || undefined })} className="w-full rounded-xl bg-[#6c5ce7]">Создать кабинет</Button></CardContent></Card></div>}
    </div>
  );
}

function Metric({ label, value }: { label: string; value: number }) { return <Card className="border-0 shadow-sm"><CardContent className="p-5"><p className="text-sm text-muted-foreground">{label}</p><p className="mt-2 text-3xl font-semibold">{value}</p></CardContent></Card>; }
function Mini({ label, value }: { label: string; value: number }) { return <div className="rounded-xl bg-white/80 p-3"><p className="text-xs text-muted-foreground">{label}</p><p className="mt-1 text-xl font-semibold">{value}</p></div>; }
function StudentCard({ student, selected, onSelect, onOpen }: { student: { id: number; name: string; email: string | null; status: string; progress: number; pendingHomework: number; shareToken: string | null; inviteToken: string }; selected: boolean; onSelect: () => void; onOpen: () => void }) { return <Card onClick={onSelect} className={`border-0 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md ${selected ? "ring-2 ring-[#6c5ce7]/30" : ""}`}><CardHeader className="flex-row items-start justify-between"><div><CardTitle className="text-xl">{student.name}</CardTitle><p className="mt-1 text-sm text-muted-foreground">{student.email || "Контакт не добавлен"}</p></div><div className="grid h-11 w-11 place-items-center rounded-2xl bg-[#eeebff] font-semibold text-[#6c5ce7]">{student.name.charAt(0)}</div></CardHeader><CardContent><div className="grid grid-cols-2 gap-3"><Mini label="Прогресс" value={student.progress} /><Mini label="Заданий в работе" value={student.pendingHomework} /></div><div className="mt-4 flex flex-wrap items-center gap-2"><Badge className="border-0 bg-[#e6f5ef] text-[#268765]"><CheckCircle2 className="mr-1 h-3.5 w-3.5" />Активен</Badge>{student.shareToken && <><Button variant="outline" size="sm" onClick={e => { e.stopPropagation(); navigator.clipboard?.writeText(`${window.location.origin}/share/${student.shareToken}`); toast.success("Ссылка скопирована"); }} className="ml-auto rounded-lg border-black/10 bg-white"><Link2 className="mr-2 h-4 w-4" />Ссылка</Button><Button variant="outline" size="sm" onClick={e => { e.stopPropagation(); navigator.clipboard?.writeText(`${window.location.origin}/invite/${student.inviteToken}`); toast.success("Ссылка приглашения скопирована"); }} className="rounded-lg border-black/10 bg-white">Пригласить</Button><Button size="sm" onClick={e => { e.stopPropagation(); onOpen(); }} className="rounded-lg bg-[#24222d]">Открыть кабинет</Button></>}</div></CardContent></Card>; }
